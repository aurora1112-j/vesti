var e,l;"function"==typeof(e=globalThis.define)&&(l=e,e=null),function(l,a,t,d,V){var U="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},n="function"==typeof U[d]&&U[d],c=n.cache||{},s="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function R(e,a){if(!c[e]){if(!l[e]){var t="function"==typeof U[d]&&U[d];if(!a&&t)return t(e,!0);if(n)return n(e,!0);if(s&&"string"==typeof e)return s(e);var V=Error("Cannot find module '"+e+"'");throw V.code="MODULE_NOT_FOUND",V}r.resolve=function(a){var t=l[e][1][a];return null!=t?t:a},r.cache={};var N=c[e]=new R.Module(e);l[e][0].call(N.exports,r,N,N.exports,this)}return c[e].exports;function r(e){var l=r.resolve(e);return!1===l?{}:R(l)}}R.isParcelRequire=!0,R.Module=function(e){this.id=e,this.bundle=R,this.exports={}},R.modules=l,R.cache=c,R.parent=n,R.register=function(e,a){l[e]=[function(e,l){l.exports=a},{}]},Object.defineProperty(R,"root",{get:function(){return U[d]}}),U[d]=R;for(var N=0;N<a.length;N++)R(a[N]);if(t){var r=R(t);"object"==typeof exports&&"undefined"!=typeof module?module.exports=r:"function"==typeof e&&e.amd?e(function(){return r}):V&&(this[V]=r)}}({"9lnB4":[function(e,l,a){e("a90f8c8a025ca3a7").register(JSON.parse('{"b89Na":"capsule-ui.f1f3c89a.js","USxDI":"Lexend-UI-400.eccfed3f.woff2","i1CcF":"Lexend-UI-500.19a404c2.woff2","h4erl":"Lexend-UI-600.edcbba37.woff2","lIcJ6":"SourceHanSansSC-UI-400.27612143.woff2","2j86x":"SourceHanSansSC-UI-500.0de68e41.woff2","a9nVW":"Exposure-Title-400.156eac3d.woff2"}'))},{a90f8c8a025ca3a7:"amLA4"}],amLA4:[function(e,l,a){var t={};l.exports.register=function(e){for(var l=Object.keys(e),a=0;a<l.length;a++)t[l[a]]=e[l[a]]},l.exports.resolve=function(e){var l=t[e];if(null==l)throw Error("Could not resolve bundle with id "+e);return l}},{}],e7XAi:[function(e,l,a){var t=e("@parcel/transformer-js/src/esmodule-helpers.js");t.defineInteropFlag(a),t.export(a,"config",()=>s);var d=e("../lib/messaging/runtime"),V=e("../lib/services/uiSettingsService"),U=e("../lib/services/capsuleSettingsService"),n=e("../lib/ui/logo"),c=e("../lib/utils/logger");let s={matches:["https://chatgpt.com/*","https://chat.openai.com/*","https://claude.ai/*","https://gemini.google.com/*","https://chat.deepseek.com/*","https://www.doubao.com/*","https://chat.qwen.ai/*","https://www.kimi.com/*","https://kimi.com/*","https://kimi.moonshot.cn/*","https://yuanbao.tencent.com/*"],run_at:"document_idle",all_frames:!1},R="vesti-capsule-root",N=[1e3,2e3,4e3],r="vesti-capsule-font-face-style",F=new URL(e("d7ce2c8aafc5aef5")).toString(),o=new URL(e("adc4149b033cce8")).toString(),p=new URL(e("ba084d101f2d599f")).toString(),Z=new URL(e("3dd5f1dd08309d80")).toString(),W=new URL(e("ca57d2c37e061caf")).toString(),h=new URL(e("ca57d2c37e061caf")).toString(),T=new URL(e("c9e1a8c2ab97831b")).toString(),i=new Set(["chatgpt.com","chat.openai.com","claude.ai","gemini.google.com","chat.deepseek.com","chat.qwen.ai","www.doubao.com","www.kimi.com","kimi.com","kimi.moonshot.cn","yuanbao.tencent.com"]),m={"chatgpt.com":"ChatGPT","chat.openai.com":"ChatGPT","claude.ai":"Claude","gemini.google.com":"Gemini","chat.deepseek.com":"DeepSeek","chat.qwen.ai":"Qwen","www.doubao.com":"Doubao","www.kimi.com":"Kimi","kimi.com":"Kimi","kimi.moonshot.cn":"Kimi","yuanbao.tencent.com":"Yuanbao"},k={light:{ChatGPT:{bg:"hsl(146 46% 93%)",text:"hsl(146 52% 28%)",border:"hsl(146 32% 76%)"},Claude:{bg:"hsl(22 86% 93%)",text:"hsl(20 54% 42%)",border:"hsl(21 55% 79%)"},Gemini:{bg:"hsl(254 86% 95%)",text:"hsl(252 45% 47%)",border:"hsl(252 52% 82%)"},DeepSeek:{bg:"hsl(222 90% 95%)",text:"hsl(222 62% 44%)",border:"hsl(222 63% 81%)"},Qwen:{bg:"hsl(242 88% 95%)",text:"hsl(242 56% 46%)",border:"hsl(242 58% 82%)"},Doubao:{bg:"hsl(210 100% 95%)",text:"hsl(212 66% 44%)",border:"hsl(211 69% 81%)"},Kimi:{bg:"hsl(222 20% 93%)",text:"hsl(222 15% 28%)",border:"hsl(222 12% 74%)"},Yuanbao:{bg:"hsl(173 62% 93%)",text:"hsl(173 58% 26%)",border:"hsl(173 35% 75%)"}},dark:{ChatGPT:{bg:"hsl(158 33% 18%)",text:"hsl(150 50% 66%)",border:"hsl(154 30% 33%)"},Claude:{bg:"hsl(18 44% 20%)",text:"hsl(18 58% 66%)",border:"hsl(18 33% 34%)"},Gemini:{bg:"hsl(252 35% 20%)",text:"hsl(252 80% 76%)",border:"hsl(252 34% 35%)"},DeepSeek:{bg:"hsl(224 44% 20%)",text:"hsl(222 88% 75%)",border:"hsl(223 35% 35%)"},Qwen:{bg:"hsl(242 42% 20%)",text:"hsl(242 88% 76%)",border:"hsl(242 33% 35%)"},Doubao:{bg:"hsl(211 46% 20%)",text:"hsl(211 90% 76%)",border:"hsl(211 37% 35%)"},Kimi:{bg:"hsl(222 20% 16%)",text:"hsl(222 18% 68%)",border:"hsl(222 14% 32%)"},Yuanbao:{bg:"hsl(173 30% 16%)",text:"hsl(173 52% 62%)",border:"hsl(173 28% 31%)"}}},b={light:{bg:"hsl(220 20% 93%)",text:"hsl(220 16% 36%)",border:"hsl(220 20% 83%)"},dark:{bg:"hsl(220 17% 22%)",text:"hsl(220 19% 73%)",border:"hsl(220 16% 36%)"}},Q={ARCHIVE_MODE_DISABLED:"Archive is disabled in mirror mode.",ACTIVE_TAB_UNSUPPORTED:"Current tab host is unsupported.",ACTIVE_TAB_UNAVAILABLE:"Active tab is unavailable.",TRANSIENT_NOT_FOUND:"No thread snapshot available yet.",missing_conversation_id:"Waiting for stable conversation URL.",empty_payload:"No parsed messages available to archive.",storage_limit_blocked:"Storage is full. Export or clean up first.",persist_failed:"Archive failed during persistence.",FORCE_ARCHIVE_FAILED:"Archive action failed. Retry.",content_unreachable:"Capture context is temporarily unreachable."},E=e=>"dark"===e?"dark":"light",S=e=>e&&"object"==typeof e?E(e.themeMode):"light",M=(e,l)=>e?k[l][e]??b[l]:b[l],u=`
@font-face {
  font-family: "Vesti Sans UI";
  src: url("${F}") format("woff2");
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  unicode-range: U+0000-00FF, U+0100-024F, U+0259, U+1E00-1EFF, U+2000-206F, U+20A0-20CF, U+2100-214F, U+2190-21FF, U+2C60-2C7F, U+A720-A7FF;
}

@font-face {
  font-family: "Vesti Sans UI";
  src: url("${o}") format("woff2");
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  unicode-range: U+0000-00FF, U+0100-024F, U+0259, U+1E00-1EFF, U+2000-206F, U+20A0-20CF, U+2100-214F, U+2190-21FF, U+2C60-2C7F, U+A720-A7FF;
}

@font-face {
  font-family: "Vesti Sans UI";
  src: url("${p}") format("woff2");
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  unicode-range: U+0000-00FF, U+0100-024F, U+0259, U+1E00-1EFF, U+2000-206F, U+20A0-20CF, U+2100-214F, U+2190-21FF, U+2C60-2C7F, U+A720-A7FF;
}

@font-face {
  font-family: "Vesti Sans UI";
  src: url("${Z}") format("woff2");
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  unicode-range: U+3000-303F, U+3400-4DBF, U+4E00-9FFF, U+F900-FAFF, U+FF00-FFEF, U+20000-2A6DF, U+2A700-2B73F, U+2B740-2B81F, U+2B820-2CEAF;
}

@font-face {
  font-family: "Vesti Sans UI";
  src: url("${W}") format("woff2");
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  unicode-range: U+3000-303F, U+3400-4DBF, U+4E00-9FFF, U+F900-FAFF, U+FF00-FFEF, U+20000-2A6DF, U+2A700-2B73F, U+2B740-2B81F, U+2B820-2CEAF;
}

@font-face {
  font-family: "Vesti Sans UI";
  src: url("${h}") format("woff2");
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  unicode-range: U+3000-303F, U+3400-4DBF, U+4E00-9FFF, U+F900-FAFF, U+FF00-FFEF, U+20000-2A6DF, U+2A700-2B73F, U+2B740-2B81F, U+2B820-2CEAF;
}

@font-face {
  font-family: "Vesti Title Serif";
  src: url("${T}") format("woff2");
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  font-synthesis: weight;
  unicode-range: U+0000-00FF, U+0100-024F, U+1E00-1EFF, U+2000-206F, U+20A0-20CF, U+2100-214F;
}
`,J=`
:host {
  all: initial;
}

.capsule-shell {
  --capsule-bg: hsl(220 24% 95%);
  --capsule-bg2: hsl(220 23% 94%);
  --capsule-bg3: hsl(220 22% 92%);
  --capsule-border: hsl(220 17% 84%);
  --capsule-divider: hsl(220 20% 88%);
  --capsule-text1: hsl(224 15% 12%);
  --capsule-text2: hsl(224 9% 36%);
  --capsule-text3: hsl(224 7% 56%);
  --capsule-shadow: 0 8px 22px rgba(28, 20, 15, 0.1), 0 2px 6px rgba(28, 20, 15, 0.08);
  --capsule-shadow-hover: 0 10px 28px rgba(28, 20, 15, 0.12), 0 3px 9px rgba(28, 20, 15, 0.1);
  --status-held-bg: hsl(36 90% 43% / 0.12);
  --status-held-text: hsl(36 90% 43%);
  --status-held-border: hsl(36 90% 43% / 0.28);
  --status-live-bg: hsl(146 50% 38% / 0.12);
  --status-live-text: hsl(146 50% 38%);
  --status-live-border: hsl(146 50% 38% / 0.28);
  --status-ready-bg: hsl(265 83% 60% / 0.12);
  --status-ready-text: hsl(265 83% 60%);
  --status-ready-border: hsl(265 83% 60% / 0.28);
  --status-neutral-bg: hsl(224 9% 36% / 0.08);
  --status-neutral-text: hsl(224 9% 36%);
  --status-neutral-border: hsl(224 9% 36% / 0.2);
  --status-error-bg: hsl(0 55% 51% / 0.1);
  --status-error-text: hsl(0 55% 51%);
  --status-error-border: hsl(0 55% 51% / 0.24);
  --btn-primary-bg: hsl(224 15% 12%);
  --btn-primary-text: hsl(0 0% 100%);
  --btn-secondary-bg: hsl(220 23% 94%);
  --btn-secondary-text: hsl(224 9% 36%);
  --btn-secondary-border: hsl(220 17% 84%);
  position: fixed;
  pointer-events: auto;
  touch-action: none;
  z-index: 2147483646;
  font-family: "Vesti Sans UI", -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
  color: var(--capsule-text1);
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
  color-scheme: light;
}

.capsule-shell[data-theme="dark"] {
  --capsule-bg: hsl(0 0% 13%);
  --capsule-bg2: hsl(0 0% 16%);
  --capsule-bg3: hsl(0 0% 17%);
  --capsule-border: hsl(0 0% 25%);
  --capsule-divider: hsl(0 0% 20%);
  --capsule-text1: hsl(0 0% 96%);
  --capsule-text2: hsl(0 0% 78%);
  --capsule-text3: hsl(0 0% 62%);
  --capsule-shadow: 0 12px 30px rgba(0, 0, 0, 0.4), 0 4px 10px rgba(0, 0, 0, 0.3);
  --capsule-shadow-hover: 0 10px 28px rgba(0, 0, 0, 0.35), 0 3px 9px rgba(0, 0, 0, 0.25);
  --status-held-bg: hsl(40 85% 58% / 0.2);
  --status-held-text: hsl(40 85% 58%);
  --status-held-border: hsl(40 85% 58% / 0.34);
  --status-live-bg: hsl(145 55% 46% / 0.2);
  --status-live-text: hsl(145 55% 46%);
  --status-live-border: hsl(145 55% 46% / 0.34);
  --status-ready-bg: hsl(262 92% 76% / 0.2);
  --status-ready-text: hsl(262 92% 76%);
  --status-ready-border: hsl(262 92% 76% / 0.34);
  --status-neutral-bg: hsl(0 0% 78% / 0.12);
  --status-neutral-text: hsl(0 0% 78%);
  --status-neutral-border: hsl(0 0% 78% / 0.26);
  --status-error-bg: hsl(0 72% 60% / 0.2);
  --status-error-text: hsl(0 72% 60%);
  --status-error-border: hsl(0 72% 60% / 0.34);
  --btn-primary-bg: hsl(0 0% 96%);
  --btn-primary-text: hsl(0 0% 10%);
  --btn-secondary-bg: hsl(0 0% 16%);
  --btn-secondary-text: hsl(0 0% 78%);
  --btn-secondary-border: hsl(0 0% 25%);
  color-scheme: dark;
}

.capsule-shell.is-dragging,
.capsule-shell.is-dragging * {
  cursor: grabbing !important;
  user-select: none;
}

.capsule-collapsed {
  width: 43.2px;
  height: 43.2px;
  border: 1px solid hsl(220 17% 84%);
  border-radius: 9999px;
  background: hsl(220 24% 95%);
  box-shadow: 0 3px 9px rgba(28, 20, 15, 0.16), 0 1px 2px rgba(28, 20, 15, 0.1);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: transform 120ms ease, box-shadow 120ms ease, background-color 120ms ease;
  cursor: grab;
  font-family: inherit;
  padding: 0;
  touch-action: none;
}

.capsule-collapsed:hover {
  transform: translateY(-1px) scale(1.02);
  box-shadow: 0 6px 14px rgba(28, 20, 15, 0.2), 0 2px 5px rgba(28, 20, 15, 0.12);
}

.capsule-collapsed:active {
  transform: scale(0.97);
}

.capsule-logo {
  width: 21.6px;
  height: 21.6px;
  object-fit: contain;
  -webkit-user-drag: none;
  user-select: none;
}

.capsule-panel {
  width: min(320px, calc(100vw - 16px));
  box-sizing: border-box;
  border: 1px solid var(--capsule-border);
  border-radius: 16px;
  background: var(--capsule-bg);
  box-shadow: var(--capsule-shadow);
  overflow: hidden;
}

.capsule-shell[data-view="collapsed"] .capsule-panel {
  display: none;
}

.capsule-shell[data-view="expanded"] .capsule-collapsed {
  display: none;
}

.capsule-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 13px 14px 11px;
  border-bottom: 1px solid var(--capsule-divider);
}

.capsule-drag-handle {
  cursor: grab;
  min-width: 0;
  flex: 1;
  display: flex;
  align-items: center;
  gap: 8px;
}

.capsule-title {
  font-family: "Vesti Title Serif", "Tiempos Headline", "Tiempos Text", "Tiempos", ui-serif, "Apple-System-UI-Serif", "BlinkMacSystemFont", serif;
  font-size: 18px;
  line-height: 1.25;
  font-weight: 700;
  font-synthesis: weight;
  letter-spacing: -0.004em;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: optimizeLegibility;
}

.capsule-platform {
  font-size: 9.5px;
  line-height: 1.2;
  font-weight: 700;
  letter-spacing: 0.2px;
  padding: 2px 7px;
  border-radius: 5px;
  border: 1px solid transparent;
}

.capsule-collapse-btn {
  width: 24px;
  height: 24px;
  font-family: inherit;
  border: 1px solid transparent;
  border-radius: 6px;
  background: transparent;
  color: var(--capsule-text2);
  font-size: 11px;
  line-height: 1;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background-color 120ms ease, color 120ms ease;
}

.capsule-collapse-btn:hover {
  background: var(--capsule-bg3);
  color: var(--capsule-text1);
}

.capsule-status-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 11px 14px 0;
  margin-bottom: 10px;
}

.capsule-status-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 10.5px;
  line-height: 1.1;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  padding: 3px 8px;
  border-radius: 20px;
  border: 1px solid transparent;
}

.capsule-status-dot {
  width: 5px;
  height: 5px;
  border-radius: 9999px;
  background: currentColor;
}

.capsule-status-badge[data-state="idle"] {
  color: var(--status-neutral-text);
  background: var(--status-neutral-bg);
  border-color: var(--status-neutral-border);
}

.capsule-status-badge[data-state="holding"] {
  color: var(--status-held-text);
  background: var(--status-held-bg);
  border-color: var(--status-held-border);
}

.capsule-status-badge[data-state="ready_to_archive"] {
  color: var(--status-ready-text);
  background: var(--status-ready-bg);
  border-color: var(--status-ready-border);
}

.capsule-status-badge[data-state="mirroring"],
.capsule-status-badge[data-state="archiving"] {
  color: var(--status-live-text);
  background: var(--status-live-bg);
  border-color: var(--status-live-border);
}

.capsule-status-badge[data-state="saved"] {
  color: var(--status-live-text);
  background: var(--status-live-bg);
  border-color: var(--status-live-border);
}

.capsule-status-badge[data-state="error"] {
  color: var(--status-error-text);
  background: var(--status-error-bg);
  border-color: var(--status-error-border);
}

.capsule-metrics {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 6px;
  padding: 0 14px;
  margin-bottom: 10px;
}

.capsule-metric {
  border: 1px solid var(--capsule-divider);
  border-radius: 9px;
  background: var(--capsule-bg2);
  padding: 8px 10px;
  display: grid;
  gap: 4px;
}

.capsule-metric-label {
  font-size: 10px;
  line-height: 1;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--capsule-text2);
}

.capsule-domain-label {
  font-size: 11px;
  line-height: 1;
  letter-spacing: 0.01em;
  color: var(--capsule-text2);
}

.capsule-metric-value {
  font-family: "Vesti Title Serif", "Tiempos Headline", "Tiempos Text", "Tiempos", ui-serif, "Apple-System-UI-Serif", "BlinkMacSystemFont", serif;
  font-size: 20px;
  line-height: 1;
  font-weight: 600;
  letter-spacing: -0.03em;
  color: var(--capsule-text1);
  font-variant-numeric: tabular-nums;
  font-feature-settings: "tnum" 1;
}

.capsule-metric-value.is-empty {
  font-size: 16px;
  color: var(--capsule-text3);
}

.capsule-reason {
  min-height: 17px;
  font-size: 11.5px;
  line-height: 1.5;
  color: var(--capsule-text2);
  margin-bottom: 12px;
  padding: 0 14px;
}

.capsule-actions {
  display: flex;
  gap: 7px;
  padding: 0 14px 14px;
}

.capsule-action-btn {
  flex: 1;
  min-height: 34px;
  font-family: inherit;
  border: 1px solid transparent;
  border-radius: 9px;
  padding: 8px 10px;
  font-size: 12.5px;
  line-height: 1;
  font-weight: 600;
  letter-spacing: 0.005em;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: var(--btn-secondary-bg);
  color: var(--btn-secondary-text);
  transition: opacity 120ms ease;
}

.capsule-action-btn:hover:enabled {
  opacity: 0.82;
}

.capsule-action-btn:disabled {
  cursor: not-allowed;
  opacity: 0.35;
}

.capsule-action-btn.is-primary {
  flex: 1.4;
  background: var(--btn-primary-bg);
  border-color: transparent;
  color: var(--btn-primary-text);
}

.capsule-action-btn:not(.is-primary) {
  border-color: var(--btn-secondary-border);
}

.capsule-status-badge[data-state="mirroring"] .capsule-status-dot,
.capsule-status-badge[data-state="archiving"] .capsule-status-dot,
.capsule-status-badge[data-state="saved"] .capsule-status-dot {
  animation: capsule-live-blink 1.6s ease-in-out infinite;
}

@keyframes capsule-live-blink {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.3;
  }
}

.capsule-shell.is-dragging .capsule-collapsed,
.capsule-shell.is-dragging .capsule-panel {
  transition: none !important;
}

.fallback-shell .capsule-collapsed {
  cursor: pointer;
}

.fallback-shell .capsule-panel {
  display: none !important;
}

.capsule-shell[data-theme="dark"] .capsule-panel {
  box-shadow: var(--capsule-shadow);
}

.capsule-shell[data-theme="dark"] .capsule-collapse-btn:hover {
  background: var(--capsule-bg3);
}

.capsule-shell[data-theme="dark"] .capsule-action-btn:hover:enabled {
  opacity: 0.82;
}

.capsule-shell[data-theme="dark"] .capsule-domain-label,
.capsule-shell[data-theme="dark"] .capsule-metric-label,
.capsule-shell[data-theme="dark"] .capsule-reason {
  color: var(--capsule-text2);
}

.capsule-shell[data-theme="dark"] .capsule-metric-value.is-empty {
  color: var(--capsule-text3);
}

.capsule-shell[data-theme="dark"] .capsule-collapse-btn {
  color: var(--capsule-text2);
}

.capsule-shell[data-theme="dark"] .capsule-collapse-btn:hover {
  color: var(--capsule-text1);
}

.capsule-shell[data-theme="dark"] .capsule-action-btn:not(.is-primary) {
  border-color: var(--btn-secondary-border);
}

.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="idle"] {
  color: var(--status-neutral-text);
}

.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="error"] {
  color: var(--status-error-text);
}

.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="holding"] {
  color: var(--status-held-text);
}

.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="ready_to_archive"] {
  color: var(--status-ready-text);
}

.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="mirroring"],
.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="archiving"],
.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="saved"] {
  color: var(--status-live-text);
}

.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="idle"],
.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="error"],
.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="holding"],
.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="ready_to_archive"],
.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="mirroring"],
.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="archiving"],
.capsule-shell[data-theme="dark"] .capsule-status-badge[data-state="saved"] {
  border-style: solid;
}

.capsule-shell[data-theme="light"] .capsule-status-badge[data-state="idle"],
.capsule-shell[data-theme="light"] .capsule-status-badge[data-state="error"],
.capsule-shell[data-theme="light"] .capsule-status-badge[data-state="holding"],
.capsule-shell[data-theme="light"] .capsule-status-badge[data-state="ready_to_archive"],
.capsule-shell[data-theme="light"] .capsule-status-badge[data-state="mirroring"],
.capsule-shell[data-theme="light"] .capsule-status-badge[data-state="archiving"],
.capsule-shell[data-theme="light"] .capsule-status-badge[data-state="saved"] {
  border-style: solid;
}

.capsule-shell[data-view="expanded"] {
  cursor: default;
}

.capsule-shell[data-view="collapsed"] .capsule-collapsed {
  cursor: grab;
}

.capsule-shell[data-view="collapsed"].is-dragging .capsule-collapsed {
  cursor: grabbing;
}

.capsule-shell[data-view="expanded"].is-dragging .capsule-drag-handle {
  cursor: grabbing !important;
}

.capsule-shell[data-view="expanded"] .capsule-drag-handle {
  cursor: grab;
}

.capsule-shell[data-view="expanded"] .capsule-collapse-btn {
  flex-shrink: 0;
}

.capsule-shell[data-view="expanded"] .capsule-platform {
  flex-shrink: 0;
}

.capsule-shell[data-view="expanded"] .capsule-title {
  flex-shrink: 0;
}

.capsule-shell[data-view="expanded"] .capsule-drag-handle {
  overflow: hidden;
}

.capsule-shell[data-view="expanded"] .capsule-title,
.capsule-shell[data-view="expanded"] .capsule-platform,
.capsule-shell[data-view="expanded"] .capsule-domain-label {
  white-space: nowrap;
}

.capsule-shell[data-view="expanded"] .capsule-domain-label {
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 170px;
}

.capsule-shell[data-view="expanded"] .capsule-actions .capsule-action-btn {
  white-space: nowrap;
}

.capsule-shell[data-view="expanded"] .capsule-reason {
  word-break: break-word;
}

.capsule-shell[data-view="expanded"] .capsule-metric-value {
  overflow: hidden;
  text-overflow: ellipsis;
}

.capsule-shell[data-view="expanded"] .capsule-metric-label {
  white-space: nowrap;
}

.capsule-shell[data-view="expanded"] .capsule-status-badge {
  white-space: nowrap;
}

.capsule-shell[data-view="expanded"] .capsule-status-row {
  min-width: 0;
}

.capsule-shell[data-view="expanded"] .capsule-status-badge {
  max-width: 160px;
}

.capsule-shell[data-view="expanded"] .capsule-status-badge .capsule-status-label {
  overflow: hidden;
  text-overflow: ellipsis;
}

.capsule-shell[data-view="expanded"] .capsule-status-badge {
  overflow: hidden;
}

.capsule-shell[data-view="expanded"] .capsule-status-dot {
  flex-shrink: 0;
}

.capsule-shell[data-view="expanded"] .capsule-status-label {
  min-width: 0;
}

.capsule-shell[data-view="expanded"] .capsule-metrics,
.capsule-shell[data-view="expanded"] .capsule-actions {
  min-width: 0;
}

.capsule-shell[data-view="expanded"] .capsule-action-btn {
  min-width: 0;
}

.capsule-shell[data-view="expanded"] .capsule-panel {
  min-width: 0;
}

.capsule-shell[data-view="expanded"] .capsule-header {
  min-width: 0;
}

.capsule-shell[data-view="expanded"] .capsule-drag-handle {
  min-width: 0;
}

.capsule-shell[data-view="expanded"] .capsule-title {
  color: var(--capsule-text1);
}

.capsule-shell[data-view="expanded"] .capsule-collapse-btn {
  color: var(--capsule-text2);
}

.capsule-shell[data-view="expanded"] .capsule-collapse-btn:hover {
  color: var(--capsule-text1);
}

.capsule-shell[data-view="expanded"] .capsule-status-row,
.capsule-shell[data-view="expanded"] .capsule-metrics,
.capsule-shell[data-view="expanded"] .capsule-reason,
.capsule-shell[data-view="expanded"] .capsule-actions {
  box-sizing: border-box;
}

.capsule-shell[data-view="expanded"] .capsule-panel,
.capsule-shell[data-view="collapsed"] .capsule-collapsed {
  -webkit-font-smoothing: antialiased;
}

.capsule-shell[data-view="expanded"] .capsule-panel {
  text-rendering: optimizeLegibility;
}

.capsule-shell[data-view="expanded"] .capsule-header {
  background: transparent;
}

.capsule-shell[data-view="expanded"] .capsule-reason {
  transition: opacity 0.2s;
}

.capsule-shell[data-view="expanded"] .capsule-panel {
  border-color: var(--capsule-border);
}

.capsule-shell[data-view="expanded"] .capsule-metric {
  border-color: var(--capsule-divider);
}

.capsule-shell[data-view="expanded"] .capsule-header {
  border-bottom-color: var(--capsule-divider);
}

.capsule-shell[data-view="expanded"] .capsule-action-btn.is-primary {
  border-color: transparent;
}

.capsule-shell[data-view="expanded"] .capsule-action-btn:not(.is-primary) {
  border-color: var(--btn-secondary-border);
}

.capsule-shell[data-view="expanded"] .capsule-collapsed {
  display: none;
}

.capsule-shell[data-view="collapsed"] .capsule-panel {
  display: none;
}

.capsule-shell[data-view="collapsed"] .capsule-collapsed {
  display: inline-flex;
}

.capsule-shell[data-view="expanded"] .capsule-panel {
  display: block;
}

.capsule-shell[data-view="expanded"] .capsule-collapse-btn:focus-visible,
.capsule-shell[data-view="expanded"] .capsule-action-btn:focus-visible,
.capsule-shell[data-view="collapsed"] .capsule-collapsed:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.25);
}

.capsule-shell[data-theme="dark"][data-view="expanded"] .capsule-collapse-btn:focus-visible,
.capsule-shell[data-theme="dark"][data-view="expanded"] .capsule-action-btn:focus-visible {
  box-shadow: 0 0 0 2px rgba(167, 139, 250, 0.32);
}
`,x=()=>{if(document.getElementById(r))return;let e=document.createElement("style");e.id=r,e.textContent=u,(document.head??document.documentElement).appendChild(e)},Y=(e,l,a)=>Math.min(Math.max(e,l),Math.max(l,a)),z=e=>String(e??"").trim().toLowerCase(),B=e=>{let l=z(e);return m[l]},G=e=>{if(!e)return null;let l=Q[e];if(l)return l;let a=Object.keys(Q).find(l=>e.includes(l));return a?Q[a]:e},X=e=>{switch(e){case"idle":return"Unavailable";case"mirroring":return"Mirroring";case"holding":return"Held";case"ready_to_archive":return"Ready";case"archiving":return"Archiving...";case"saved":return"Saved";case"error":return"Action failed"}},w=async()=>!!chrome?.runtime?.sendMessage&&new Promise(e=>{chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL",source:"capsule-ui"},()=>{let l=chrome.runtime.lastError;e(!l)})}),H=e=>e<=0?3e3:e<=N.length?N[e-1]:3e3,D=async()=>{if(window.top!==window.self||document.getElementById(R))return;x();let e=z(window.location.hostname),l=i.has(e),a=U.DEFAULT_CAPSULE_SETTINGS;try{a=await (0,U.getCapsuleSettingsForHost)(e)}catch(l){(0,c.logger).warn("content","Failed to load capsule settings, fallback to defaults",{host:e,error:l.message})}let t="light";try{let e=await (0,V.getUiSettings)();t=E(e.themeMode)}catch(l){(0,c.logger).warn("content","Failed to load UI theme settings, fallback to light",{host:e,error:l.message})}if(!a.enabled||a.hiddenHosts.includes(e)){(0,c.logger).info("content","Capsule hidden by settings",{host:e});return}let s=document.createElement("div");s.id=R,s.style.position="fixed",s.style.inset="0",s.style.pointerEvents="none",s.style.zIndex=String(2147483646),document.body.appendChild(s);let N=s.attachShadow({mode:"open"}),r=document.createElement("style");r.textContent=J,N.appendChild(r);let F=document.createElement("div");F.className=l?"capsule-shell":"capsule-shell fallback-shell",F.dataset.view="collapsed",F.dataset.state="idle",F.dataset.theme=t,N.appendChild(F);let o=document.createElement("button");o.type="button",o.className="capsule-collapsed",o.setAttribute("aria-label","Vesti capsule"),o.title=l?"Open Vesti capsule":"Open Vesti Dock";let p=document.createElement("img");p.className="capsule-logo",p.src=n.LOGO_BASE64,p.alt="Vesti",p.draggable=!1,o.appendChild(p),F.appendChild(o);let Z=document.createElement("section");Z.className="capsule-panel",Z.hidden=!0;let W=document.createElement("div");W.className="capsule-header";let h=document.createElement("div");h.className="capsule-drag-handle",h.setAttribute("role","presentation");let T=document.createElement("span");T.className="capsule-title",T.textContent="Vesti";let m=document.createElement("span");m.className="capsule-platform",m.textContent=B(e)??"Unknown";let k=B(e),b=M(k,t);m.style.backgroundColor=b.bg,m.style.color=b.text,m.style.borderColor=b.border,h.appendChild(T),h.appendChild(m);let Q=document.createElement("button");Q.type="button",Q.className="capsule-collapse-btn",Q.textContent="^",Q.setAttribute("aria-label","Collapse capsule"),Q.title="Collapse",W.appendChild(h),W.appendChild(Q);let u=document.createElement("div");u.className="capsule-status-row";let D=document.createElement("span");D.className="capsule-status-badge",D.dataset.state="idle";let g=document.createElement("span");g.className="capsule-status-dot";let v=document.createElement("span");v.className="capsule-status-label",v.textContent="Unavailable",D.appendChild(g),D.appendChild(v);let j=document.createElement("span");j.className="capsule-domain-label",j.textContent=e,u.appendChild(D),u.appendChild(j);let y=document.createElement("div");y.className="capsule-metrics";let O=document.createElement("div");O.className="capsule-metric";let f=document.createElement("span");f.className="capsule-metric-label",f.textContent="Messages";let I=document.createElement("span");I.className="capsule-metric-value is-empty",I.textContent="--",O.appendChild(f),O.appendChild(I);let C=document.createElement("div");C.className="capsule-metric";let L=document.createElement("span");L.className="capsule-metric-label",L.textContent="Turns";let K=document.createElement("span");K.className="capsule-metric-value is-empty",K.textContent="--",C.appendChild(L),C.appendChild(K),y.appendChild(O),y.appendChild(C);let P=document.createElement("div");P.className="capsule-reason",P.textContent="Waiting for status...";let A=document.createElement("div");A.className="capsule-actions";let q=document.createElement("button");q.type="button",q.className="capsule-action-btn is-primary",q.textContent="Archive now";let _=document.createElement("button");_.type="button",_.className="capsule-action-btn",_.textContent="Open Dock",A.appendChild(q),A.appendChild(_),Z.appendChild(W),Z.appendChild(u),Z.appendChild(y),Z.appendChild(P),Z.appendChild(A),l&&F.appendChild(Z);let $="collapsed",ee={anchor:U.DEFAULT_CAPSULE_SETTINGS.anchor,offsetX:U.DEFAULT_CAPSULE_SETTINGS.offsetX,offsetY:U.DEFAULT_CAPSULE_SETTINGS.offsetY},el=$,ea=null,et=null,ed="idle",eV=!1,eU=0,en=null,ec=null,es=0,eR=!1,eN=!1,er={...ee},eF=0,eo=!1,ep=null,eZ={active:!1,pointerId:null,source:null,canDrag:!1,startedWithModifier:!1,dragging:!1,startX:0,startY:0,startLeft:0,startTop:0},eW=()=>{let e=F.getBoundingClientRect();return{width:Math.max(e.width||0,43.2),height:Math.max(e.height||0,43.2)}},eh=(e,l,a)=>{let{width:t,height:d}=eW(),V=window.innerWidth-t-8,U=window.innerHeight-d-8;return{anchor:e,offsetX:Y(l,8,V),offsetY:Y(a,8,U)}},eT=()=>{let e=eh(er.anchor,er.offsetX,er.offsetY);if(er={anchor:e.anchor,offsetX:e.offsetX,offsetY:e.offsetY},a={...a,anchor:e.anchor,offsetX:e.offsetX,offsetY:e.offsetY},F.style.top="auto",F.style.bottom=`${e.offsetY}px`,"bottom_right"===e.anchor){F.style.left="auto",F.style.right=`${e.offsetX}px`;return}F.style.left=`${e.offsetX}px`,F.style.right="auto"},ei=(e,l,a)=>{let t={action:e,state:ed,ok:l,...a};l?(0,c.logger).info("content","Capsule action",t):(0,c.logger).warn("content","Capsule action failed",t)},em=l=>{ep={...ep??{},...l},eo||(eo=!0,(async()=>{for(;ep;){let l=ep;ep=null;try{let t=await (0,U.updateCapsuleSettingsForHost)(e,l);a={...t,anchor:er.anchor,offsetX:er.offsetX,offsetY:er.offsetY}}catch(a){(0,c.logger).warn("content","Failed to persist capsule settings",{host:e,patch:l,error:a.message})}}eo=!1})())};if(l){let e=a.defaultView!==$||a.anchor!==ee.anchor||a.offsetX!==ee.offsetX||a.offsetY!==ee.offsetY;e&&em({defaultView:$,anchor:ee.anchor,offsetX:ee.offsetX,offsetY:ee.offsetY})}let ek=()=>eV?"archiving":eU>Date.now()?"saved":et?"error":ea&&ea.supported?"content_unreachable"===ea.reason?"error":"mirror"===ea.mode?"mirroring":ea.available?"ready_to_archive":"holding":"idle",eb=()=>{if("error"===ed)return G(et)??"Action failed";switch(ed){case"idle":return"Open an active chat thread to continue.";case"mirroring":return"Mirror mode saves content automatically.";case"holding":return"Waiting for archivable thread snapshot.";case"ready_to_archive":return"Thread snapshot ready for manual archive.";case"archiving":return"Persisting snapshot...";case"saved":return"Archive completed.";default:return null}},eQ=()=>{if(eR)return;if(ed=ek(),F.dataset.view=el,F.dataset.state=ed,F.dataset.theme=t,!l){F.classList.add("fallback-shell");return}Z.hidden="expanded"!==el,o.hidden="expanded"===el,D.dataset.state=ed,v.textContent=X(ed);let a=ea?.platform??B(e)??"ChatGPT";m.textContent=a;let d=M(a,t);m.style.backgroundColor=d.bg,m.style.color=d.text,m.style.borderColor=d.border;let V="number"==typeof ea?.messageCount?String(ea.messageCount):"--",U="number"==typeof ea?.turnCount?String(ea.turnCount):"--";I.textContent=V,K.textContent=U,I.classList.toggle("is-empty","--"===V),K.classList.toggle("is-empty","--"===U),q.disabled="ready_to_archive"!==ed,q.textContent="archiving"===ed?"Archiving...":"Archive now",P.textContent=eb()??""},eE=()=>{eR||eZ.dragging||window.requestAnimationFrame(()=>{eR||eZ.dragging||eT()})},eS=(e,a=!0)=>{l&&el!==e&&(el=e,eQ(),eE(),a&&em({defaultView:e}))},eM=async()=>{let l=await w();ei("open_dock",l,{host:e})},eu=()=>{ec&&(window.clearTimeout(ec),ec=null),a.autoCollapseMs<=0||(ec=window.setTimeout(()=>{eR||(eU=0,eS("collapsed",!1),eQ(),eE())},a.autoCollapseMs))},eJ=e=>{l&&!eR&&(en&&(window.clearTimeout(en),en=null),en=window.setTimeout(()=>{ex()},e))},ex=async()=>{if(l&&!eR)try{let l=await (0,d.sendRequest)({type:"GET_ACTIVE_CAPTURE_STATUS",target:"background"},5e3);ea=l,et="content_unreachable"===l.reason?"content_unreachable":null,es=0,eQ(),eE(),(0,c.logger).info("content","Capsule status",{host:e,platform:l.platform,mode:l.mode,state:ek(),supported:l.supported,available:l.available,paused:!1,reason:l.reason,messageCount:l.messageCount,turnCount:l.turnCount,updatedAt:l.updatedAt}),eJ(3e3)}catch(l){es+=1,et=l.message||"ACTIVE_TAB_UNAVAILABLE",eQ(),eJ(H(es)),(0,c.logger).warn("content","Capsule status polling failed",{host:e,failureCount:es,error:et})}},eY=async()=>{if(!l||"ready_to_archive"!==ed)return;let e=Date.now();eV=!0,et=null,eQ();try{await (0,d.sendRequest)({type:"FORCE_ARCHIVE_TRANSIENT",target:"background"},1e4),eV=!1,eU=Date.now()+a.autoCollapseMs,eQ(),eu(),ei("archive_now",!0,{durationMs:Date.now()-e}),ex()}catch(l){eV=!1,et=l.message||"FORCE_ARCHIVE_FAILED",eQ(),ei("archive_now",!1,{durationMs:Date.now()-e,error:et})}},ez=(e,l)=>{if(!e.isPrimary||0!==e.button||eZ.active)return;eZ.active=!0,eZ.pointerId=e.pointerId,eZ.source=l,eZ.startedWithModifier="collapsed"===l&&e.altKey,eZ.canDrag=!0,eZ.dragging=!1,eZ.startX=e.clientX,eZ.startY=e.clientY;let a=F.getBoundingClientRect();eZ.startLeft=a.left,eZ.startTop=a.top;let t=e.currentTarget;t.setPointerCapture(e.pointerId),e.preventDefault()},eB=e=>{if(!eZ.active||eZ.pointerId!==e.pointerId||!eZ.canDrag)return;let l=e.clientX-eZ.startX,a=e.clientY-eZ.startY;if(!eZ.dragging&&5>=Math.hypot(l,a))return;eZ.dragging||(eZ.dragging=!0,F.classList.add("is-dragging"));let{width:t,height:d}=eW(),V=Y(eZ.startLeft+l,8,window.innerWidth-t-8),U=Y(eZ.startTop+a,8,window.innerHeight-d-8);F.style.left=`${V}px`,F.style.top=`${U}px`,F.style.right="auto",F.style.bottom="auto",e.preventDefault()},eG=(e,l)=>{if(!eZ.active||eZ.pointerId!==e.pointerId)return;let a=e.currentTarget;a.hasPointerCapture(e.pointerId)&&a.releasePointerCapture(e.pointerId);let t=eZ.dragging,d=eZ.startedWithModifier,V=eZ.source;if(t){let e=F.getBoundingClientRect(),l=e.left+e.width/2>=window.innerWidth/2?"bottom_right":"bottom_left",a="bottom_right"===l?window.innerWidth-e.right:e.left,t=window.innerHeight-e.bottom,d=eh(l,a,t);er={anchor:d.anchor,offsetX:d.offsetX,offsetY:d.offsetY},eF=Date.now(),eT(),em({anchor:d.anchor,offsetX:d.offsetX,offsetY:d.offsetY}),ei("drag_end",!0,{anchor:d.anchor,offsetX:d.offsetX,offsetY:d.offsetY}),eN=!0}else"collapsed"===V&&d&&!l&&(eN=!0);eZ.active=!1,eZ.pointerId=null,eZ.source=null,eZ.canDrag=!1,eZ.startedWithModifier=!1,eZ.dragging=!1,F.classList.remove("is-dragging")},eX=(l,d)=>{if(eR||"local"!==d)return;let V=l.vesti_ui_settings;if(V){let l=S(V.newValue);l!==t&&(t=l,eQ(),eE(),(0,c.logger).info("content","Capsule theme updated",{host:e,themeMode:t}))}let n=l.vesti_capsule_settings;n&&(async()=>{if(!eR&&!eZ.dragging&&!(Date.now()-eF<2e3))try{let l=await (0,U.getCapsuleSettingsForHost)(e);if(eR)return;a=l,er={anchor:l.anchor,offsetX:l.offsetX,offsetY:l.offsetY},eQ(),eE()}catch(l){(0,c.logger).warn("content","Failed to sync capsule settings",{host:e,error:l.message})}})()},ew=()=>{eE()},eH=()=>{eR||(eR=!0,en&&(window.clearTimeout(en),en=null),ec&&(window.clearTimeout(ec),ec=null),window.removeEventListener("resize",ew),window.removeEventListener("pagehide",eH),window.removeEventListener("beforeunload",eH),"undefined"!=typeof chrome&&chrome.storage?.onChanged&&chrome.storage.onChanged.removeListener(eX),s.remove())};o.addEventListener("keydown",e=>{if("Enter"===e.key||" "===e.key){if(e.preventDefault(),l){eS("expanded");return}eM()}}),l?(o.addEventListener("click",e=>{if(eN){eN=!1,e.preventDefault();return}eS("expanded")}),o.addEventListener("pointerdown",e=>{ez(e,"collapsed")}),o.addEventListener("pointermove",e=>{eB(e)}),o.addEventListener("pointerup",e=>{eG(e,!1)}),o.addEventListener("pointercancel",e=>{eG(e,!0)}),h.addEventListener("pointerdown",e=>{ez(e,"expanded")}),h.addEventListener("pointermove",e=>{eB(e)}),h.addEventListener("pointerup",e=>{eG(e,!1)}),h.addEventListener("pointercancel",e=>{eG(e,!0)}),Q.addEventListener("click",()=>{eS("collapsed")}),q.addEventListener("click",()=>{eY()}),_.addEventListener("click",()=>{eM()})):o.addEventListener("click",()=>{eM()}),window.addEventListener("resize",ew),window.addEventListener("pagehide",eH),window.addEventListener("beforeunload",eH),"undefined"!=typeof chrome&&chrome.storage?.onChanged&&chrome.storage.onChanged.addListener(eX),eQ(),eE(),l?ex():(0,c.logger).info("content","Capsule fallback mode enabled for host",{host:e,mode:"fallback_open_dock_only"})};"loading"===document.readyState?window.addEventListener("DOMContentLoaded",()=>{D()},{once:!0}):D()},{"../lib/messaging/runtime":"lk4Tp","../lib/services/uiSettingsService":"bbbvr","../lib/services/capsuleSettingsService":"itgST","../lib/ui/logo":"l3M79","../lib/utils/logger":"7QsIM",d7ce2c8aafc5aef5:"9T4FN",adc4149b033cce8:"cljvb",ba084d101f2d599f:"9NolI","3dd5f1dd08309d80":"f9lbz",ca57d2c37e061caf:"kLs50",c9e1a8c2ab97831b:"6mRIM","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],lk4Tp:[function(e,l,a){var t=e("@parcel/transformer-js/src/esmodule-helpers.js");async function d(e,l=4e3){return new Promise((a,t)=>{let d=setTimeout(()=>{t(Error(`Timeout after ${l}ms`))},l);try{chrome.runtime.sendMessage(e,e=>{clearTimeout(d);let l=chrome.runtime.lastError;if(l){t(Error(l.message));return}a(e)})}catch(e){clearTimeout(d),t(e)}})}async function V(e,l){let a=await d(e,l);if(!a.ok)throw Error(a.error||"Request failed");return a.data}t.defineInteropFlag(a),t.export(a,"sendMessageWithTimeout",()=>d),t.export(a,"sendRequest",()=>V)},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],cHUbl:[function(e,l,a){a.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},a.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},a.exportAll=function(e,l){return Object.keys(e).forEach(function(a){"default"===a||"__esModule"===a||l.hasOwnProperty(a)||Object.defineProperty(l,a,{enumerable:!0,get:function(){return e[a]}})}),l},a.export=function(e,l,a){Object.defineProperty(e,l,{enumerable:!0,get:a})}},{}],bbbvr:[function(e,l,a){var t=e("@parcel/transformer-js/src/esmodule-helpers.js");t.defineInteropFlag(a),t.export(a,"DEFAULT_UI_SETTINGS",()=>V),t.export(a,"applyUiTheme",()=>c),t.export(a,"getUiSettings",()=>s),t.export(a,"setUiThemeMode",()=>R),t.export(a,"subscribeUiSettings",()=>N),t.export(a,"initializeUiTheme",()=>r);let d="vesti_ui_settings",V={themeMode:"light"};function U(){return"undefined"!=typeof chrome&&chrome.storage?.local?chrome.storage.local:null}function n(e){let l=e&&"object"==typeof e?e:V;return{themeMode:"dark"===l.themeMode?"dark":"light"}}function c(e){if("undefined"==typeof document)return;let l=document.documentElement;l.classList.toggle("dark","dark"===e),l.style.colorScheme=e}async function s(){let e=U();return e?new Promise((l,a)=>{e.get([d],e=>{if(chrome.runtime?.lastError){a(Error(chrome.runtime.lastError.message));return}l(n(e?.[d]))})}):V}async function R(e){let l=n({...V,themeMode:e}),a=U();return a&&await new Promise((e,t)=>{a.set({[d]:l},()=>{if(chrome.runtime?.lastError){t(Error(chrome.runtime.lastError.message));return}e()})}),l}function N(e){if("undefined"==typeof chrome||!chrome.storage?.onChanged)return()=>{};let l=(l,a)=>{if("local"!==a)return;let t=l[d]?.newValue;void 0!==t&&e(n(t))};return chrome.storage.onChanged.addListener(l),()=>{chrome.storage.onChanged.removeListener(l)}}async function r(){let e=await s();return c(e.themeMode),e.themeMode}},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],itgST:[function(e,l,a){var t=e("@parcel/transformer-js/src/esmodule-helpers.js");t.defineInteropFlag(a),t.export(a,"DEFAULT_CAPSULE_SETTINGS",()=>V),t.export(a,"getCapsuleSettingsForHost",()=>F),t.export(a,"updateCapsuleSettingsForHost",()=>o);let d="vesti_capsule_settings",V={enabled:!0,defaultView:"collapsed",autoCollapseMs:2e3,anchor:"bottom_right",offsetX:24,offsetY:100,draggable:!0,hiddenHosts:[]};function U(){return"undefined"!=typeof chrome&&chrome.storage?.local?chrome.storage.local:null}function n(e,l){return"boolean"==typeof e?e:l}function c(e,l){let a=Number(e);return Number.isFinite(a)?Math.min(1e5,Math.max(0,Math.round(a))):l}function s(e){return String(e??"").trim().toLowerCase()}function R(e,l){var a,t,d,V;let U=l&&"object"==typeof l?l:void 0;return{enabled:n(U?.enabled,e.enabled),defaultView:(a=U?.defaultView,t=e.defaultView,"expanded"===a?"expanded":t),autoCollapseMs:function(e,l){let a=Number(e);return Number.isFinite(a)?Math.min(1e4,Math.max(0,Math.round(a))):l}(U?.autoCollapseMs,e.autoCollapseMs),anchor:(d=U?.anchor,V=e.anchor,"bottom_left"===d?"bottom_left":V),offsetX:c(U?.offsetX,e.offsetX),offsetY:c(U?.offsetY,e.offsetY),draggable:n(U?.draggable,e.draggable),hiddenHosts:function(e){let l=Array.isArray(e)?e:[],a=[],t=new Set;for(let e of l){let l=String(e??"").trim().toLowerCase();!l||t.has(l)||(t.add(l),a.push(l))}return a}(U?.hiddenHosts??e.hiddenHosts)}}async function N(){let e=U();return e?new Promise((l,a)=>{e.get([d],e=>{if(chrome.runtime?.lastError){a(Error(chrome.runtime.lastError.message));return}l(function(e){let l=e&&"object"==typeof e?e:void 0,a=l&&"global"in l?l.global:l,t=R(V,a),d={},U=l?.hosts&&"object"==typeof l.hosts?l.hosts:{};for(let[e,l]of Object.entries(U)){let a=s(e);a&&(d[a]=R(t,l))}return{global:t,hosts:d}}(e?.[d]))})}):{global:V,hosts:{}}}async function r(e){let l=U();if(l)return new Promise((a,t)=>{l.set({[d]:e},()=>{if(chrome.runtime?.lastError){t(Error(chrome.runtime.lastError.message));return}a()})})}async function F(e){let l=s(e),a=await N(),t=l?a.hosts[l]:void 0;return R(a.global,t)}async function o(e,l){let a=s(e),t=await N(),d=R(t.global,a?t.hosts[a]:void 0),V=R(d,l);return a&&(t.hosts[a]=V,await r(t)),V}},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],l3M79:[function(e,l,a){var t=e("@parcel/transformer-js/src/esmodule-helpers.js");t.defineInteropFlag(a),t.export(a,"LOGO_BASE64",()=>d);let d="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1MTIiIGhlaWdodD0iNTEyIiB2aWV3Qm94PSIwIDAgNTEyIDUxMiI+PGltYWdlIGhyZWY9ImRhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBZ0FBQUFJQUNBWUFBQUQwZU5UNkFBQUFCSE5DU1ZRSUNBZ0lmQWhraUFBQUFBbHdTRmx6QUFBT3hBQUFEc1FCbFNzT0d3QUFBQmwwUlZoMFUyOW1kSGRoY21VQWQzZDNMbWx1YTNOallYQmxMbTl5WjV2dVBCb0FBQ0FBU1VSQlZIaWM3TjE1ZUZ4VitRZnc3M3Z1VE5JS1NRc0l0T3kwWVRNMG1YdnZwREVFSkN5eUwvN1FJb3ZJb2lDaTRJcTRJeXFyaWdvb0NpZ2lpRUpkV0dXSG9KUVNNdmZlSkNVRkpCUVFJV0d6YlFxa2s1bDczOThmbVdBb1RacGxaczZaeWZ0NUhoNEttYm4zbStuY09XZk9QZWM5Z0JCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkRpWGNoeG5KdHpmMTQ1NHY4ekVhMTY1eitZUTJidVYwcXRpYUxvVFNKNms1bjdBYXhTU3IyWnlXVGVqTWZqYXp6UFcxM1U5RUlJSWNRMDRycnVyRXdtVXhXUHh6ZU9vbWhqQUxPSnFKcVpOeWFpcXR5L3E0bklHbjRPTTg4R1FDTU9zd2t3MUFIZ1BPZGJDZUFWQUs4QmVCVkFINERYaU9nMVp1NGxvdUUvditoNTN0dDVQcmNRUWdoUk11cnE2amFxcUtqWWhwazNaK2JOaVdndU0yOE9ZSE1BY3dCc01lTFBzL041N2tKMEFDWmlKWUJlQUM4RFdNSE1LNVJTSzVoNUJUUDNCa0h3c3Nac1FnZ2h4SlEwTlRYTnpHYXpjN1BaN0R3aW1rZEU4NWg1SGpOdlJVUnpBZXlJZDM4N0x4cmRIWUFOV1EzZ0dRQlBBWGlTbVorT291aXBiRGI3VEhkMzk2RG1iRUlJSVFScWEyc3JaczZjdVhNWWhyc1MwUzRBZGdPd0s0Q2RBRlRyVFRjNjB6c0FvOGtDZUE3QWt4anFIRHhGUkoxcjE2NTlRam9HUWdnaENxRzJ0clppeG93WnUwZFJsQ0NpWFRIVXlPK0dvVy94MXRqUE5rK3BkZ0JHa3dYd0x3QWVFWGtBdkV3bUUzUjFkYjJsT1pjUVFvZ1NVbHRidTNGbFplVXV6RndMd0FYZ0VwRUxZSWJtYUhsVGJoMkE5UWtCUE1QTVBnQVB3TkxCd1VGUFJncUVFRUlBUTkvc0t5b3FYS1hVSGdCY1pyWUI3QXhBYVk1V1VOT2hBN0ErR1FCZHpMeEVLZlZJRkVXdFFSQzhwanVVRUVLSXduTmRkMVlVUlExRXRDZUE1dHcvTXpYSEtycnAyZ0ZZbjZjQlBNck1TNGpvWWQvM2UzUUhFa0lJTVhXSlJHSW5wVlFMZ0QySWFBOW0zbGx6SkNOSUIyQjB2UUFlQVhCL0dJWjNkbloydnFRN2tCQkNpQTJ6Ylh0enBWUUxNKzhQNEFBQU8yaU9aQ1RwQUl6ZkNnRDNFOUg5QU82VnFvZENDR0VHMTNYZkYwWFJIa3FwL1hPTnZnTk5hK3RMaVhRQUppY0Q0RkVpdW9PSWJrK2xVay9yRGlTRUVOTkpNcG5jSllxaUl3QWNDbUFQQUhITmtVcU9kQUR5WXdXQSt3SGNrVTZuNzVFVkJrSUlrVitMRmkyeVZxeFkwUVRnTUdZK0hNQUhkR2NxZGRJQnlMK1ZBTzVuNWp1eTJlenR5NVl0VzduQlp3Z2hoSGlQQlFzV2JGSlJVYkYvcnNFL0RMbE5iRVIrU0FlZ3NFSm1ma3dwdFRpS29odGxxYUVRUW93dGtVak1KcUlqaUdnUmdBTWhRL3NGSXgyQTRnbVorVEVpK2owUjNTU1RDSVVRWWtodVhmNlJ1VWIvQUFBVnVqTk5COUlCMENNTjRENW1YbHhSVVhGTFcxdGJ2KzVBUWdoUlRFMU5UVFBUNmZUK0FCWUIrQ2lBOTJtT05PMUlCMEMvQVFDM0FyaHUvdno1OXkxZXZEalVIVWdJSVFwaDBhSkZWazlQendGRWRCS0FJMUJHZGZWTGtYUUF6UEl5TS8rWmlIN2orMzZYN2pCQ0NKRVBydXZ1eXN6SEFEZ0p3UGFhNDRnYzZRQ1l5eU9pNnkzTHV1SHh4eDkvUTNjWUlZU1lpQkgzOVU4QXNCK2tNSTl4cEFOZ3ZnRWl1b1daci9GOS95RUE4dmNsaERBVjJiYTlIeEY5R3NDUmtDRitvMGtIb0xROHc4eS9tVEZqeHRWTGx5NzlyKzR3UWdnQkFJMk5qZFdaVE9ZWUlqcUxtV3QxNXhIakl4MkEwclFXd09Jb2lpN3Q2T2pvMEIxR0NERTlKWk5KTzRxaTB3RWNEMkFqM1huRXhFZ0hvUFI1QUs2cXJLeThmdW5TcFFPNnd3Z2h5bHR0YlczRmpCa3pqbVRtMHdEc3J6dVBtRHpwQUpTUFY0bm9xbGdzZGtWYlc5c3J1c01JSWNwTFEwUERuREFNendSd0tvRE5kZWNSVXljZGdQSXpDT0FtWnI0b0NJTGx1c01JSVVxYjR6ZzF6SHdtRVowS1lLYnVQQ0ovcEFOUXZoakFBd0F1ODMzL2R0MWhoQkNseFhYZFBabjVMQUJIQWJCMDV4SDVKeDJBNlNGZzVwL05talhyeHRiVzFxenVNRUlJWXluSGNRNEY4RTBBSDlRZFJoU1dkQUNtbHhVQUxrbW4wOWQyZDNjUDZnNGpoREJEVFUxTjVheFpzMDRCY0RZejc2ZzdqeWdPNlFCTVR5OFMwVStxcXFwKzNkcmF1bFozR0NHRUhyVzF0UldWbFpVbkVkRjNtSGtiM1hsRWNVa0hZQnBqNWxjQS9IVEdqQm1YeVJKQ0lhYVA0WVlmd0hjQmJLMDVqdEJFT2dBQ0FGNWw1a3VsSXlCRWVhdXBxYW1zcnE0K0VkTHdDMGdIUUx4Ykw0QkxxcXVyZnlXM0JvUW9IMDFOVFRQWHJsMzdXUUJmSTZJdGRlY1JacEFPZ0hnUEl2b1BNLzlnL3Z6NXYxbThlSEdvTzQ4UVl0S1U2N29mQlhDeFRPNFQ2eUxidHM4aElvdUlxb2YvSnpOdkRDQ2UrODhZZ0tyY2Y4L0svVE43eEo5anhZMHNpb1dJdXBuNUcxSkhRSWpTazBna2psUktYUURnQTdxemlJTEpBbGlkKzJmVmlEOW5BS3pKL1J3QU1rVDA1dkNUbUxtZm1jTXA3ODljVjFlM2tXVlpzNVJTMVFCbU1mTVdBT2FPK0djclp0NlNpTFlHc0FYKzE3RVFwZU1ScGRUWFU2blVFdDFCaEJCamN4eG5Md0FYQWRoRGR4WXhZUmtNemNsNmlZajZpT2hsWnU3RDBPM1pYaUo2RmNEcUtJcjZ3ekJjM2RYVjlkWlVUamJsRHNCRXo5ZlkyTGpGNE9EZ0hDS2FSMFR6QWN5UG9taCs3cy9iUVVZVWpFVkV0MFpSOUUwcE1TeUVlWkxKNU81UkZGMEk0RERkV2NTb3NnQmVBUEFzTXorcmxIb1d3TE5SRkQxWFVWSFJWK3g5WElyZEFSaVQ2N3B4REhVQzVnT1l6OHc3QVZqQXpBdGs0b294UW1hK05nekRiM1YxZGIycU80d1EwMTFqWStPV21Vem1BZ0FuQVZDYTQ0Z2hmY3k4aklpZUlLSm5BRHdMNE5tcXFxb1hUS3JHYWxRSFlDd0xGaXpZcEtLaW9wYVpQOERNdFFCY0lxb0hzTEh1Yk5QVW13QiswdC9mZjJGUFQwOWFkeGdocHB2Y0Y2WXptUGs4RE0zSEVzVTNDS0FIZ01mTTNVUzBuSWhTbnVmMTZnNDJIaVhUQVJpRmNoeG5Iak1uaVdnaGdFWUFEb0FabW5OTkowOHo4NWVDSUxoTGR4QWhwb3RrTW5rSU0vK1VtWGZXbldVYVdjdk1ubEtxalpuYkFQaSs3NjhBRU9rT05sbWwzZ0Y0ajVhV2x0aktsU3Qzc1N5ckdjQ2VBRndBdTZFTWYxZkQzQitHNFJjN096dTdkUWNSb2x3bEVvbWRsRktYUXU3ekYwTXZnRWVJYUFrQXI2cXFLbFZ1OVZHbVJhUG91dTc3bWZtRHpOeENSUHNBU0VEdWxSWENJSURMNHZINEQ5cmEydnAxaHhHaVhEUTJObFlQRGc1K2w0ak9CRkNoTzA4WkNnRjBBSGlJaUZvdHkzcnM4Y2NmZjBOM3FFS2JGaDJBZFRVMU5XMmFUcWYzem5VRzlzM05LUkQ1MDVlN0xmQW4zVUdFS0hXMmJSOUxSSmNDbUtNN1N4bGhBTjNNL0NBelB4aUc0VCtXTFZ1MlVuZW9ZcHVXSFlCMU5UWTJiams0T0xoUHJrTndJSUR0ZFdjcUUzZGJsdlc1OXZiMkZicURDRkZxWE5lZHo4eS93TkJua3BpNjV3SGNBK0RCYkRiYktxdVlwQU93WGcwTkRmT2lLRHFjbVE4RDBBS3BUVEFWQXdBdVNhZlRGM1IzZHcvcURpT0U2VWJNN2o4ZndFYTY4NVN3Q0VBQTRBNEF0L3UrNzJQb203L0lrUTdBQml4Y3VIQ3pNQXozWmViREFSd0JXVzR6V2N1aUtEcTlvNlBqVWQxQmhEQlZNcGxzanFMb1Z3QjIxNTJsUkwwRjRDRUF0eFBSN2FXeUhFOFg2UUJNUUcxdGJVVkZSY1dIaU9oSUFCK0QzSk9icUlpSXJnckQ4QnNkSFIycmRJY1J3aFFMRml6WUpCNlBYd1RnVk1qbjhrVDFFdEdmb3lpNlZTbjFEOC96TXJvRGxRcDVvMDJDYmR2MWxtVjlOWXFpNHlDckNTYWpqNGcrNjNuZUxicURDS0diNHpoSE1mTXZwZHJweEJIUlFCUkYxMFJSZEhGblorZEx1dk9VR3VrQVRJRHJ1bnN5OHprQURvVzhkdm13T0JhTGZYWTZMTGNSWWwySlJHSzJVdXBpQUtmcHpsSUdCZ0hjRkliaER6czdPLytsTzB5cGtFWnNIR3piM2h2QStVVFVyRHRMR1hxWmlFN3pQTzlPM1VHRUtCYmJ0bzhnb2w5RGJpUG1XeGJBSDdQWjdMbGRYVjNQNlE1ak91a0FqTUcyN1E4UTBmY0FMTktkWlJwWVhGbFplZnJTcFV2L3F6dUlFSVhpdXU0c1pyNEU4cTIvMERJQXJyVXM2OXoyOXZZKzNXRk1KUjJBOVdob2FOZzJETU52QS9nVUFFdDNubW1rRjhCbmZOKy9YWGNRSWZMTmNad0RpZWdhWnQ1R2Q1WnA1QzBpdWdMQWhaN25yZFlkeGpUU0FSaWh1Ym01YW1CZzRMc0F6Z1JRcVR2UE5NVUFya21uMDEvdTd1NStVM2NZSWFhcXVibTVhdTNhdFQ5bDVrL3B6aktOdmNiTTM2MnBxYmw2OGVMRm9lNHdwcEFPUUk3ak9JY0R1QUxBZHJxekNBREFNOHg4WEJBRUtkMUJoSmlzWkRLNU1JcWlHd0hNMTUxRkFBQ0NLSW8rTC9WSWhrejdEa0I5ZmYzT2xtVmREdUFBM1ZuRWUyUUJuTy83L3ZkUndsdHVpbW1KWE5jOUszZS9YemJ2TVFzRHVDR2J6WDUxdXBjRG5yWWRnTHE2dW8wc3l6cVBpTTRDRU5lZFI0enBRV1krSVFpQ2wzVUhFV0pER2hzYnQ4eGtNcjhEY0pEdUxHSk1Ld0Y4eC9mOUt6Rk52MkJNeXc1QXJ0em10UUIyMHAxRmpOdHJBRTd4ZmY4TzNVR0VHRTBpa1RoU0tYVU5nUGZyemlMRzdWR2wxQ21wVk9wcDNVR0tiVnAxQUpxYW1tWU9EZzZleTh4blF5cjRsYXJyaWVoMHovUGUxaDFFaUdFdExTMHpWcTllZlRFUm5ZbHA5cmxhSmdhWStieWFtcG9mVDZkSmd0UG1qWnBJSlBhd0xPdGFadDVaZHhZeFpWMWhHQzZTaWwvQ0JLN3I3c3JNaXlFYitKU0RwVVIwaXVkNVQra09VZ3hsM3dHb3JhMnRxS3lzUEIvQWx5SGYrc3ZKR2lMNmxPZDVpM1VIRWROWGJzai9Pc2d1b2VWa0FNRFp2dS8vUW5lUVFpdnJEb0J0MjlzVDBSOEJOT25PSWdxQ0FmeWt1cnI2RzYydHJWbmRZY1QwNGJwdW5Ka3ZCdkFsM1ZsRVlSRFJyUlVWRmFlVWMzWFNzdTBBT0k1ekZJQnJBR3lpTzRzb3VIOFMwY2RsNzI5UkRIVjFkVnZFWXJFL0F0aFhkeFpSY0M4UzBYR2U1ejJpTzBnaGxGMloyNWFXbGhtYmJMTEpUNGpvVWdBemRlY1JSYkU5Z0UvT21UUEg3K3Zya3cxQVJNSFl0djBoeTdMdUIxQ25PNHNvaWxrQVBqbDM3bHhyenozMy9PZnk1Y3RaZDZCOEtxc09RQ0tSMkdGd2NQQitJanBTZHhaUmRCc1IwWEZ6NXN3WjdPdnJreXBmSXQvSWRkMHZBTGdCY3I5L3VsRUFXbGF1WE5tdzVaWmIzdG5YMTdkV2Q2QjhLWnRiQUs3cjdobEYwWitKYUV2ZFdZUjJpNG5vSkZrcUtQS2hycTV1bzFnc2RoMkFqK3JPSXJUckNjUHdJNTJkbmQyNmcrUkRXWFFBSE1jNURVTjEvS1dpbnhnV1dKWjFaSHQ3KzR1Nmc0alM1YnJ1ZHN4OEc0QjYzVm1FTWRZQU9OSDMvYi9wRGpKVkpYMExvS1dsSmJiWlpwdjlETUFQVU9LL2k4aTd1Y3g4d3B3NWM5cjYrdnBlMEIxR2xCN2J0cHNBM0ErZ1JuY1dZWlJLQUVkdnRkVldNM3Q3ZXgvRTBHcWtrbFN5SXdDSlJHSTJFZjJOaUZwMFp4RkdTd000M2ZmOTMra09Ja3FINjdySE1mTnZBTXpRblVXWWk1bHZIQndjUExtN3UzdFFkNWJKS01sdnpmWDE5VnRibHZVQUVUWHF6aUtNRndQd2tUbHo1bXk2MTE1NzNWZHVzM2hGZmkxYXRNaWFPWFBtaGN4OEtZYmVPMEtNaW9nV3hHS3hQYmJiYnJ0YlhucnBwYlR1UEJOVmNpTUFqdVBzQnVCdUFOdnB6bElpWGdYd0pJQi9FZEYvbVBsRkFMMWhHTDVZV1ZuWmw4MW02d0ZjaXVseGovTnVJanJHODd6VnVvTUk4elEzTjFjTkRBemNBT0FJM1ZtS1lEa3pmN1dpb3NJUHczQ3JLSXEyWWVhdEFXeEZSUE1BN0pMN3AwcHZ6SkxSeWN5SGxOcU9wU1hWQVVnbWs4MWhHTjVHUkp2cXptS2dESWJlaE8wQVBDTHF6bVF5VHk5YnRtemxocDY0YU5FaXE2ZW41d3dpK2dIS2ZJa1RFWFZIVVhSb0VBUXlMMEM4bzY2dWJzZFlMSFluZ04xMFp5bXdWVVQwTGMvemZvVnhiSUZiWDErL3RWSnFWNlhVN3N6Y0FDQUpZR2VVV050UkpDOEFPTmozL1NkMUJ4bXZrdmxMZEYzMzBOeUdHMUxjWjhncUlub1l3RU1BSGx1OWVuVkhUMC9QbElhZ0dob2E1b1JoZUFtQUUvS1MwRng5UkhTbzUzbSs3aUJDUDhkeDZnRDhIY0RXdXJNVTJCM1piUGF6WFYxZC81bktRVnpYblJWRlVWSXAxUnhGMFQ1RTFJU2hpWEhUSGpQLzE3S3NnMU9wMU9PNnM0eEhTWFFBYk5zK2dvZ1dBNmpRblVXakxJQi9BTGduaXFLSGR0cHBKNzlRMjFZbWs4bVdLSXAraWZMK052UW1NeDhkQk1GZHVvTUlmV3piM3ArSS9nS2dXbmVXQXVvaG9zOTVubmR2SVE3ZTFOUTBjKzNhdGMxRXRBOFJIY0xNaVVLY3A0VDBSMUYwY0VkSGgvRUZ5WXp2QU9TKytmOEYwN09IT1FEZ0FRQzN4K1B4Vzl2YTJsNHAxb2xkMTQxSFVmUmxJdm9leW5jbWRCYkFHYjd2WDYwN2lDZysxM1ZQWk9hclViNzFRd1lBWE5MZjMzL2hWRWNISnlLM0NkdUJBQTRIY0NESzkvVWR5MXRFZExqbmVRL3BEaklXb3pzQXRtMS9OTGViMzNSNkEyVXhOTW54aHNyS3l0dVdMbDA2b0RPTTY3cnptZmtLQUFmcHpGRkFET0Q3dnU5L1QzY1FVVHkyYlo5RFJCZkM4TS9BS1hndzk2MWY2NzcyQ3hjdTNDd013NDh6OHljdy9YWmxmVXNwZFZncWxXclZIV1EweHI3NUhjYzVHc0FmTUgyVzRnUkVkRjBtay9salYxZlhxN3JEck11MjdST0k2T2NvMDkwVmllaFg4K2JOKzN5aGJxc0lNN1MwdE1SV3IxNTlKUkY5V25lV0FubURpTTd5UE85RzNVSFc1VGhPRFlCUEFEZ1J3QTU2MHhUTjI4eDhaQkFFOStzT3NqNUdkZ0FjeHprY3dGOVEvdC84QndIY3lzeFhtZm9HR2NtMjdhMkk2TmNBRHRPZHBVQnVJNkpqWlErQjhwU3I2WDhUZ0VOMVp5a0VJcnBWS1hWNmUzdDduKzRzRzZCczI5NlhpRTREY0JSS3RCN05CQXdBT05EMy9YL3FEckl1NHpvQXRtMS9pSWp1Um5uUDluK1ZpSDZobExxcUJDN1c5M0JkZHhFelh3bGdNOTFaQ3VBUklqcE1hZ1dVbDBRaU1Wc3BkU2VBUFhSbktZQlZBTTd4ZmY4cTNVRW1xcjYrZm1mTHNzNEE4Q2tBRyt2T1UwQ3JBT3p0KzM2WDdpQWpHZFVCeUMzSGFVV1pEak1ENkdQbW55bWxMaS8xYjVtNUpZTlhBdmlJN2l3RjREUHpRVUVRdktZN2lKaTZ1cnE2TGVMeCtEMWxPanY5cmpBTVQrM3M3SHhKZDVDcGFHeHNyQjRjSFB3c2dLK1ZjWjJYMTVSU2U2VlNxYWQxQnhsbVRBY2drVWpzcEpSNkJNQVd1ck1VUUE4elh6ZzRPSGhEcWRhTUhrMFpqd1k4RlliaC9xWCt3VHJkdWE0N2w1bnZCYkM3N2l4NXRockExMHJ4Vy85WWN0VVlUMmZtcjVUajF1NUU5RndVUlh1YVVqSFFpQTVBN3Q3eW93QzIxNTBsbjVqNUZhWFU5d0ZjN1hsZVJuZWVRc245L1YwTDRBRGRXZkxzMld3MisrR3VycTduZEFjUkUrZTY3bndBOXpIempycXo1Tms5ekh5S0tZMUlJZFRXMW00OFk4YU1MelB6VjFGKzVZaWZpS0pvcjQ2T2psVzZnMmp2QU9TS1NMUVMwVUxkV2ZMb0xTSzZJaGFMWGREVzF0YXZPMHlSa091Nlp6SHp4U2l2bWcyOVNxa0RVcW5VRTdxRGlQRnpYWGRYWnI0ZjVWWGRMd1BnQXQvM3Y0OXhsUEV0QjdsbGhHY3o4eGRRWHZWSUhrNm4wd2ZvSGhIVzNRRWcxM1Z2WnVhUGFjNlJMd3pnQnN1eXZsYUtrL3Z5d1hWZEI4QWZtWGxuM1ZueXBkVEtlMDUzcnVzNnpIdzNnTTExWjhtanA1VlN4NlpTcVVCM0VCMGN4NmxoNXA4VDBTRzZzK1RScjMzZlAxMW5BSzBkQU1keGZnamdXem96NU5IVHpQejVVbGpPVjJpMXRiVWJWMVpXWGdiZ1pOMVo4bWdWaGpiNmVFeDNFREc2WkRMWkhFWFJuU2lqVGEyWStab3dETC9ZMWRYMWx1NHN1am1PY3pnUi9ieU1idXQ4eWZmOW4razZ1YllPZ09NNHh3TzRYbWVHUEhrYndMZXJxNnN2YjIxdHplb09ZNUpjSmNlclVUNnJPdnFKNkFEUDg5cDBCeEh2WmR0MlUyNEpjYm5VOVYvTnpKOE5ndUNQdW9PWXBLbXBhV1k2bmY0V2dLK2g5R3ZGaEVSMHBPZDVkK280dVpiRzEzWGRSbVp1UmVuZjAza0V3TW0rNy9mb0RtSXExM1czWStZYkFPeWxPMHVlck03TkNaRGJBUWJKRGZ2ZmovTHBiRDVtV2RieDdlM3RLM1FITVZYdTcveGFBSFc2czB6Um1qQU1tem83Tzd1TGZXSlY3Qk0yTlRWdHlzeC9RbWszL2dQTS9QWDU4K2UzU09NL05zL3ovbDFkWGIwdmdCOWphSTVFcVpzVlJkSGRqdU80dW9PSUlZbEVvb0daSDBSNU5QN016QmZObno5L1Qybjh4K1o1bms5RVNXYitPb2FxcXBhcXFsZ3M5dGZHeHNhaWoxd1Zld1JBT1k1ekI0Q0RpM3pldkNHaURpSTZ4cVJpRHFVaXQ2M3o3MUVlOTJkWE1mT0hneUJJNlE0eW5TVVNpUVFSUFZBbXhXUFc1SmIzL1ZsM2tGSmoyM1l5dDNGY2plNHNVL0FuMy9lUExlWUppem9DNExydXQxRENqVCtHNWl3MFMrTS9PVUVRM0JhRzRVSUE1YkNrYmpZUjNTY2pBZnJZdGwydmxMcS9UQnIvcDVqNWc5TDRUMDRRQkttWk0yYzZHTnBBcmxRZDR6ak81NHA1d3FLTkFMaXV1dzh6MzRmUzNQaWhIOEJwdnUvZnBEdElPY2l0RXJnR3dNZDFaOG1EbFVTMHYrZDV2dTRnMDBtdWJQZ0RBTjZ2Tzh0VUVkRWZNNW5NcVRMTFB6OXMyLzRrRWYwU3dFYTZzMHhDSm9xaWxvNk9qa2VMY2JLaWRBQmMxNTBiUlZGUW9xVWRuN0FzNjBpNUg1ZDNaTnYybDRqb1lwVCtscyt2TVhOTEVBVExkUWVaRHVycjYyc3R5MnBGNlRmK0dTTDZxdWQ1bCtrT1VtNGN4Nmtqb2x0S2RMbmdDNWxNeGw2MmJObktRcCtvS0xjQW1QbnFFbTM4N3lRaW1ZeFRHQndFd2FYTXZCK0FVaSthdExsUzZoN2J0c3VxbExXSjZ1cnFkclFzNjE2VWZ1UC9zbEpxSDJuOEM4UDMvUzdMc2hvd05FcFVhcmF2cUtqNFJURk9WUEFSQU1keFBnUGdWNFUrVDU0eEVWM2llZDQzTVUxS2J1cVUyMHZnTmdDbGZqKzl4N0tzdmFackZjaENzMjE3Y3lMNko0QmRkR2Vab2s3THNnNXZiMjkvVVhlUWN0ZlMwaEpiczJiTkQ1bjVITjFaSm9xWmp3MkM0RStGUEVkQk93QU5EUTN6d2pEc1JHbnQ4enhJUkNkN25uZWo3aURUU1YxZDNVYXhXT3dHbFA3MndsMlpUS2FsR01OMzA0bnJ1ck9ZK1NFQXR1NHNVL1FYSXZwa3FXOEhYbXBjMXoyRG1TOURDYzFCWStiL1JsRlVWOGdkU1F2NVlxZzVjK2I4RlVBcDFZUi9FOEJSdnUvL1RYZVE2ZWFWVjE3SjlQYjIzangzN2x3QWFORWNaeXEydEN6clE1dHZ2dm1mWG5ubGxiTGRBYktZbXBxYVptYXoyYjhEYU5TZFpTcVkrYklnQ0Q3ZDI5dGJ5bXZXUzFKdmIyLzdsbHR1MlVsRVI2SkVxZ2NTMFV3aVd0RFgxM2REb2M1UnNBNkE0emhuQS9oMG9ZNWZBSDFFOUdIZjkvK3BPOGgwMXR2YjJ6cG56cHdYaWVoZ2xGQnZmUjNiS3FYcXR0cHFxei8zOXZiS0xhUXBjRjAzbnMxbS93SmdmOTFacGlCTlJKLzJmZjhpbEVjeHJKTFUxOWYzOUZaYmJmVXdnUDhETUZOM252RWdvdmx6NTg1OXJiZTN0NzBReHkvSUpNQkVJckVUZ1BNS2Nld0NlY0d5ckdaWnltV0dJQWgrcTVUYUY4QnJ1ck5Nd1dHNU1xVkZyN1paUm9pWnJ3SndxTzRnVS9BR014L29lZDUxdW9NSXdQTzhSOEl3M0F1bE5mSDRJdGQxdHl2RWdRdnk0YVNVK2lWS3A5VHZ2eTNMMmxkbStwc2xsVW90QWJBSGdLZDBaNW1DNHgzSCtZbnVFS1hLY1p6TEFKeWtPOGRrRVZGM05wdHRDSUxnWWQxWnhQOTBkbloyaDJHNE40Q0MzVnZQczQyaktMcXlFQWZPZXdmQXR1MFRVRHJEZFM5a3M5a1dhZnpONVB0K1R5YVQyUU5EbXk2VnFpODZqdk5GM1NGS2pldTZYd1h3ZWQwNUppdTMyVmx6VjFmWGM3cXppUGZxN096OFZ4UkYreERSZjNSbkdROGlPc1IxM2J4UGtNN3JLb0NtcHFaTjArbjBrd0MyeU9keEMyU0ZaVmt0c2hUSGZEVTFOWld6WnMyNmdaay9wanZMSkVVQVBpYVRTOGNudDQzMHpTalIyeWRFZEd0RlJjV3hTNWN1SGRDZFJZek5jWndhSW5xSW1iZlJuV1ZEaU9nL00yYk0rTUNTSlV2VzVPdVllYjNBQmdjSEwwRnBOUDZ2aG1GNHNEVCtwYUducHljOWI5NjhZd0JjcFR2TEpDa0FmM0FjNTRPNmc1Z3V0Nm5MNzFHaWpUK0EzMVZWVlgxTUd2L1M0UHQrVHhpRyt6THpLN3F6YkFnemJ6TXdNUEQ5ZkI0emJ5TUF0bTAzRWRHU2ZCNnpRRllTMGQ2ZTV5M1RIVVJNR0RtT2N5NkFjM1VIbWFUWGlLako4N3huZFFjeFVhN0szOUlTclJvS0lyclk4N3l2Njg0aEppNlJTRFFvcFI0QVVLVTd5d2FFek93R1FkQ1pqNFBscTdFbTI3Yi9TVVROZVRwZW9Rd1EwUUdlNTVYeVBlV0NTU1FTc3pGVTFyWWFBSlJTVldFWXhwUlNJVFAzQTBBWWhtdmU5NzczdmI1MDZkTC82c3JwT003bkFmd2NwZmt0OGNsTUp0TXNoWUxlTFZmbzV4RUF1K3ZPTWdrTTRDdSs3LzlVVjRDRkN4ZHVsazZuTjdNc2E3Z0JtOFhNeXJLc2JCUkZ3MFBHcTZNb2VyMmpvMk9WcnB3bXkyMVk5M2VZUDRIOUlkLzM5ODNIZ2ZMU0FYQWM1MmdBcHUrVUZ3TDRpTy83ZCtnT29rdHRiVzNGekpremE4TXdYQUJnTnlMYUFjQ09BTFlIc0RrbXR1NCtZdWJYaU9qZkFKNEQ4RHlHWnV4M1ZWZFhkN2UydHE3TmEvaDFPSTV6RklhMi9qVDlZbDJmaDlQcDlBSGQzZDFTRUFaRGEvMlorUzRBKytuT01nbURBRDVaNkoxQ201cWFacWJUNlE4d2N6MFI3WUtoNjNZSFp0Nk9pRGJIeERyRFdRQ3ZZK2lhZlo2Wm53UHdKRE12eTJReXk2ZnorOUp4bkk4RCtDUE1IOGsrUEI5dDJaUi95ZHJhMm9yS3lzcmxBT1pQOVZpRnhNeGZDWUxnVXQwNWlzbTI3ZTJKYUM4QVRRQ2FBZFNpT0R2dmhRQ2VCUEFvTXkrSnhXS1BGR0tsUlRLWi9IQVVSWDlEYVc3N2VhM3YrNmZvRG1FQWNoem5PZ0FuNkE0eUNXOENPTkwzL1FmemZlRGM1TFJtWm00bW9qMlllVmNVcHpCV0JzQnlESzI4V1VwRS8vUTg3OTlGT0s4eFhOZjlMak9iWHNmbUtTS3E4enh2U3RWR3A5d0J5Rlg4dTJTcXh5bXczL20rZjdMdUVJWG11bTRjd0Q3TWZEQ0FnMkhXcGlrOUFPNW01cit2V2JQbXdaNmVublErRHVxNjdwN01mQ2VBNm53Y3I4aSs1dnYrajNTSDBNbHhuRzhDT0Y5M2prbDRVeWwxZUNxVmFzM0h3VnBhV21hc1diTm12eEhYN3J4OEhEZFBuaVNpdTRqb2JtWnVuV3FqVXdMSWNaenJBUnl2TzhoWWlPaHpudWY5Y2tySG1NcVRGeTVjdUZrMm0rMEJNSHNxeHltd3NoNXVYYlJva2JWaXhZcjlBQndkUmRIL0VkR211ak9OdzJwbXZzV3lySnMzM25qamUxdGJXN05UT1podDIwa0E5NVRJN3o1U2xHdEUvcTQ3aUE2TzR4d0k0RTZVWHNubjFRQU84bjMvc2FrY0pIZnI0MEFBUndNNEVxWFJpWDJEbWY4RzRLYWFtcHFIRmk5ZUhPb09WQWd0TFMweit2djdId0pnOHNxZDE0aG9KOC96VmsvMkFGUHExRUExWEFBQUlBQkpSRUZVQURpT2N3bUFzNmR5akFMcnN5ekxMc2Z0V1czYjNnckFDVVIwT29BZE5NZVppajRpdWc3QTFWT1pIZSs2cnNQTTl3TFlMSC9SaW1JbGdJVys3L2ZvRGxKTTlmWDFPMXVXMVFhenZ6eXN6eXFsMUlHcFZPcnh5UjZncnE1dUc4dXlqaWVpendIWU5vL1ppdTFsSXJvK0RNTmZkWFIwUEs4N1RMNDFORFRNQ2NNd0FEQkhkNVl4bk9mNy92Y20rK1JKZHdCeTMvNmZnN25MSnJJQTlpMjN6WDJTeVdSekZFVmZBWEFFU3UrYjAxZ2lacjViS2ZWanovTWVtc3dCa3Nta0hVWFJ2UURlbitkc2hmWVVFWDF3S2ozNVV0TGMzRnkxZHUzYXBjeGNxenZMQksxazVnT0NJRWhONXNtMmJlOUhSRjhCY0JETW4yUTJFU0dBVzVuNXgwRVFMTlVkSnA5eUt3UHVnN21mdGFzem1jeU9rMTFWTk9sbFZHRVluZzF6RzM4UTBUZktxZkYzSE9kd3gzR1dSbEgwQ0laMnN6TDFEVGxaaW9nT1llWUhIY2Z4Yk52K0tDYjRJWmxLcFFKbTNodWx0ZEVIQU93SzREcVU1ckxHaVZJREF3Ti9LTUhHLzFVaTJuc1NqYjl5SE9kbzEzVURJcm9mUS9mM3k2bnhCNFkraTQ0aW9rY2R4MW5pdW00cGI5NzBMcDduUFVSRWVTMitrMmV6NHZINFdaTjk4cVRlaUs3cnZqKzNkR1RqeVo2NHdHN3pmZjhqS0lPdE4zT1QzTTRIOENIZFdUUjRnb2krNzNuZW56R0J2MHZYZFhkbDVnY0FiRlc0YUFYeFBkLzNUWjk5UENXdTYvNkFtYit0TzhkRU1QTXJVUlR0MTluWjJUMlI1OW0ydlQ4UlhRekFLVkEwazdVQk9OLzMvZHQxQjhrRDVUak9YUUFPMEIxa0ZLdUlhSWZKakNCTzZodEhiZ2phMU1iL3RYZzhmaHBLdlBGM1hYZFgyN2J2Wk9aL1lubzIvZ0N3T3pQZjdEak8wb21VMGZVODd5a01iVWoxYXVHaUZjUjNFNG5Fa2JwREZJcmpPRWN4ODdkMDU1aWd2aWlLUGpTUnh0OTFYY2R4bkg4UTBYMllubzAvQURRQ3VNMXhuUHRkMTEyZ084d1VSVVIwRW9BM2RBY1p4V3dBWDVqTUV5YzhBbUQ2dlg5bVBqSUlndHQwNTVpc1JDSXhXeWwxUG9EVFVKdzErNlVpSXFKckFYemQ4N3pYeC9PRVJDS1JVRW85aE5LYWFMWUdRS1B2KzAvcURwSlA5ZlgxdFpabFBRWnp2emlzenh0S3FaWlVLdlhFZUI1Y1YxZTNSU3dXdXhqQUp6RTlidWVNVjVhSXJnVHduVktlNTJKNHdidVZSTFRqUkYvZkNiOUpNNW5NWjJGbzQwOUV2eW5seHQ5eG5NTXN5MW9HNEF4STQ3OHV4Y3lmWXVaL09ZNXoybmllME5IUjBVRkVCMkdvVVMwVlZVUzAySFhkOStrT2tpOTFkWFViV1paMU0wcXI4ZStQb3VqZzhUYitydXN1aXNWaVR3QTRDZEw0cnl2R3pHY3k4MU81dVQwbHlmZjltNW41UnQwNVJyRUpnRTlQOUVrVEdnSElyVnQ5SG1iZVczMGhIby9YdGJXMTllc09NbEc1VVpVckFTelNuYVdFM0dsWjFxZkhzOFRUY1p4OU1iVGV2SlRLQnBkTnBVRFhkYTlqNWsvcXpqRUJBOHg4Y0JBRUQyL29nYTdyem1YbTMyQm9jcDhZbjVzcUt5dlAwTG1meUdRdFdMQmdrM2c4dmd6QTFycXpyTWZ6MWRYVk8wMmtyc3FFZXFyTS9IR1kyZmdEd0ptbDJQamJ0cjFmTnB2dGhEVCtFM1ZvR0laZHRtMGZzYUVIK3I3L0lCRWRDU0F2MVFlTDVHVEhjVTdTSFdLcVhOZjlkSWsxL29ORXRHZzhqYi9qT0FjeHN3OXAvQ2ZxNCtsMHV0dHhuSU4wQjVtbzNISzdTYys2TDdBZFZxOWUvWkdKUEdGQ1M4bm16Smx6TlJFWjEvTWhvai83dnY5RDNUa21ZdEdpUmRiTW1UTXZCUEJybEVZRk1CTnRSRVRIekprelo5T3R0OTc2Z2Q3ZTNtaTBCL2IyOWo0N2QrN2M1UUEraXRJWm9qMW96cHc1ZC9UMTlSbS9WL242SkpQSjNabjVMd0RpdXJPTVV3amdFNzd2M3pMV2cycHJheXUyM1hiYnl6QzBJMlVwM2RZd3ljWUFqcHM3ZDI3Rm5udnUrZkR5NWN0TFp0SjJiMi92azNQbnpuVmdWcWwxQUFBUmJkUGIyL3ZiY1Q5K3ZBL01MVWN6Y1YxOWZ4aUdIK2pzN0h4SmQ1RHhXcmh3NFdhWlRPYVBSUFJoM1ZuS0JUTXZBWEIwRUFRdmovVTQxM1ZQWk9iZm9rUTZBVVQwcnhrelppU1hMRmxTU3ZNWVVGZFh0MUVzRm1zSHNKdnVMT1BFekh4cUVBUy9HZXRCOWZYMVcxdVd0UmhERzJ5SlBHRG0xakFNUDk3VjFWVXlxM1pjMTkyT21idGhZQWN3VjFTc2JUeVBIZmVISURNYk9lekJ6Tjh1cGNiZmNaeTZiRGJyUytPZlgwVFVURVNwWkRLNWNLekhlWjUzSFJGOXJWaTVwb3FaZHg0WUdQaUY3aHdUWlZuV1ZTaWR4aDlFOU1VTk5mNjJiVGNwcFR4STQ1OVhSTlFTaThYYWtzbms3cnF6akZkdWgwUWpDd1JGVVRUdXRucGNIWUM2dXJvdEFFem8za0tSUERscjFxd3JkWWNZTDl1Mjl3ZndEd0RiNmM1U3B1WkdVZlJ3YmsvdlVYbWU5eE1NRGQrV2loTnMyLzZVN2hEajVUak9hVVIwbk80Y0UvQmp6L011RytzQmp1TWNSVVQzRTlHV3hRbzF6ZXdRUmRHanRtMlh6SHdLSXZvWmdHZDA1MWdYRVgzTWRkMXhsVU1mVndjZ0hvK2ZBQVB2NHltbHZqclZuZVNLeFhHY2s0bm9MZ0N6ZEdjcGN6TUEzT2c0enVmSGVwRHYrMThHOE5maVJKbzZJcnE4dnI3ZStQSzV1YUl2UDlPZFl3SnU5bjMvbkxFZTREak9Gd0VzQmxBMlN6TU5WVVZFdDlxMlhSS1RSblBiSW45ZGQ0NzFxQUF3cmc3NHVEb0FoczdpZmFoVXRsRzFiZnQwQU5kQTF2WVhpd0p3dWV1NkY0M3htS2l5c3ZJVHVia0RwV0JtTEJhN3FhV2x4ZGlsakRVMU5aWE1mRDJBbWJxempOTS9xNnVyVHdRdzZ1UlIyN2JQQWZCVGxNaWNrVElRSjZMZnVhNDdxY3AyeGViNy9sOEJHRGMzanBuSFZSTmdnMjlxMTNVYkFkUk5PVkYrUlVUMFZkMGh4c054bkxOelZiRGtBNlRJbVBrY3gzSE9IKzNuUzVjdUhZakg0MGNDZUxxSXNTYU5tV3Y3Ky91TnZPOElBTE5temJvQVFMM3VIT1AwWkdWbDVVZGFXMXZYanZZQTI3WXZKS0t4T3BHaU1JaVpmK3E2YmtsOHhpdWx2b0F4T3BHYUxIQmRkNE5scURmWUtER3pjY1ZJaU9nbXovTjgzVGsyeEhYZHN3QmNvanZITlBkTngzSE9IZTJIanovKytCdlpiUFpnWmk2VnBYWmZ5UlUyTW9wdDJ4OWk1aS9xempGT3ZWRVVIVEpXSVJyWGRYOUFSQ1lPNzA0WHhNdy9Lb1ZPUUNxVkNnQ011WFJVQjJZK2VVT1BHYk1Ea0N0SE91YUVLZzJpS0lxTVgvTnYyL1lwekZ4SzkwTEwyZmR5UTducjFkWFY5UnlBd3dDOFZieElrNmFJNkxvRkN4WnNvanZJc0VRaU1adUlya2RwakhLOVRVVC8xOUhSOGZ4b0QzQWM1MHVsdG1OaHVXTG1TeHpIK1l6dUhCdkN6TitIWVJ2UU1mTnhHN3BsdUtFTDlsQ1lOMm50NWlBSWx1c09NUmJidGo5R1JGZWovUGI5TGxsRWRPRllsZldDSUVneDgzRXdieWp2UFpoNW0zZzhmcm51SE1PVVVsZWlORmEyaE16OHNiSFdTRHVPY3lxQVM0dVlTWXlOQVB6U2Naei8weDFrTEVFUWRNS3dVUUFpMm5UVnFsVUhqdldZTVRzQXpHemF4ZzBSRVYyZ084UllFb2xFQXhGZGg5TDROalNkRUlDcmtzbmtxUFVYZ2lDNGpZaEtaYnZhNDIzYlBsWjNDTnUyVHdCd2pPNGM0MEZFNXdSQmNOZG9QM2RkZHg4QVZ4UXhraGdmQmVBUHRtMGJYWDhoaWlMalJnR1VVbU8yNGFOK1EyMXFhcHFaVHFkZmhWbVZqdjdxKzc1cG5aSjMxTlhWN1JpTHhkb0FiSzQ3aXhqVktnQjdqTEhkTHJtdSt3ZG0xdDY0anNNcUlxclBGU1VwdXJxNnVtMWlzVmdYaG5ZaU05ME52dStmTU5vUGs4bms3bEVVTFlHVTVUWldicDVPWXhBRUwrak9NaHJIY1c3SDBPMUVVNnp1NysvZnNxZW5aNzM3b0l6NkxUV2RUaDhFc3hwL0tLV01IWnByYVdtWkVZdkYvZ3hwL0UwM200aHVjVjEzdEZ0YmpLRnROWTJmWkFwZ2RxNnNzWTViVFdSWjF2VW9qY2EvdmJLeWN0UXRwSnVibTZ1aUtGb01hZnlOUmtSYkV0R3RobStWL1ZQZEFkWXhxN3E2ZXRSUno3R0dxVTM3cHUyblVpbGoxMnozOS9kZkNXQ0R5eTZFZnN5OE16UC9IcU0wbko3bnZjM01od01ZYzE4QlErem5PTTZFOXdHZkt0ZDFQMHRFTGNVKzd5VDBaYlBabzVZdVhUb3d5czlwWUdEZ09nQzdGak9VbUxSNlp2NjE3aENqeWUwODJxRTd4enBHYmN2WDJ3R29xYW1waEZuREdJQjVQYXQzNUNZT25hUTdoNWlRSTJ6Yi90Sm9Qd3lDNE9Vb2loYWhOTFlRL25GRFE4TzJ4VHBaZlgzOTFzeHM5RnljbkF5QW83dTZ1djR6MmdOczIvNGFBS01ubUluMytJVGpPQnRjNHFZTE00OVpWbHFEajlUVzFsYXM3d2ZyN1FETW1qVnJiNWcxKzc4dm5VN2ZyRHZFK3JpdU94L0FUM1RuRUJOSFJCY2tFb25FYUQvdjZPaDRGTURwUll3MFdkWFpiUFpYeFRxWlpWbS9oRm1mRDZQNW5PLzdvMVpwYzEzWElTSmpDeXVKTVYxZVgxKy9zKzRRNjlQZjMzOGpBSk4yTnB4ZFdWbTU1L3ArTU5vdGdER1hEaFFiTTEvYjNkMDlxRHZIdWx6WGpUUHpud0JVNmM0aUpxVlNLZldIcHFhbVVVdlgrcjcvT3dERzc4WkhSSWNVWTFWQXJrNzdFWVUrejFReDgyVys3MTg5MnM5ZDEzMGZNLzhCUTNYVFJlblpTQ2wxdmV1Nnh1MVJrNXR3ZDUzdUhDTVIwUUhyKy8vcjdRQXc4M29mckl0UzZ2ZTZNNnhQRkVYbkFFanF6aUdtNUFQcGRQcDdZejJBaUw0RTROSGl4Sms4SXZxNWJkc0ZtNFRhMk5pNEpSRVpPeEYzR0RNdm1UVnIxbGMyOEpnZlF1NzdselFpV2dqQXlFcUJTcW5md0tBbGdhTzE2ZS9wQU5UWDEyOE53S1JkeC83cGVkNVR1a09zSzVsTTdsSkNhOGJGMkw3c09JNDcyZzg5ejh0a3M5bVBBM2k5aUprbVkzT2xWTUcyT2M1a01wY0QyS3hReDg4SFp2NHZnT1BIMmlVMG1Vd3VCRER1UGRPRnVaajVYTWR4ZHRPZFkxMnBWT3BwQUkvcHpqRkN3blhkdWV2K3ovZDBBQ3pMT2dCbVZiQzdWbmVBOWFBb2lxN0IwTmF6b3ZURkFGeTFhTkVpYTdRSGRIVjEvU2UzSzZiUmxRS1orVmpYZFQrUzcrTTZqbk00Z0VYNVBtNmVNWUNUeDFvbjN0TFNFc3RkdTZQK1hZdVNVc25NdjRSWmJkWXdrOW91WXViOTF2MmY2N3NGWU5Mdy85dnBkSHF4N2hEcmNoem5PQURyblZSUlJ0WUNlQVBBQ2d4OTh4MXRHVlc1Y0o1OTl0a3hsOU1GUVhBWEVmMm9XSUVtaTVtdkdLUE93WVFsRW9uWkFJeGRlaldNbVM4S2d1QzJzUjZ6ZXZYcXp3SllVS1JJdWd4ZzZKcGRnYUZyZU5RZEQ4c0JFYlU0am1OYzV6UWVqOThFczE3Nzk4enRXN2ZYUkk3anZBSnppdG44eGZmOWora09NVkt1Q01YVHpMeU43aXg1OGd3elB3eWdTeW4xZEJpRy85cHBwNTFlWEx4NGNiaWV4eXJYZGJlSm9taG5wZFRPQUJZdzg5NEFqQnVDbTZUWG9pamF1YU9qWTlWb0QyaHBhWW4xOS9jL0NHQ3ZJdWFhakovN3ZwK1gzZmtjeDdrQ3dPZnljYXdDK2tkMWRmVitZdzM5TnpVMWJicDI3ZHBuaUdqVFlnWXJvQ2VKNkdFQXk2SW8rbGNzRm51NnZiMzlKYXhubEdyUm9rWFdNODg4czYxbFdUc0QyRFdLb2dXNU9nNDFSYzVjS0M5VVZsYnVOa2E5QnkxYzE3MkZtWS9VblNPbnovZjlkOTBHZUZjSElKbE03aEpGa1RIMzI1bjUyQ0FJL3FRN3gwaXU2MzZYbWMvVG5XTUtRZ0FQQVBoVE5wdTliNncxMHVQbHV1N2MzUERTeHdFY2hLRWg5WkxFekQ4SmdtRE1pVVVORFExendqQU1BTXdwVXF6SkNLTW9TblowZEV5cEtFa3ltYlNqS0dxSDJVUG1yNFpoNkhSMmRyNDAxb01jeC9rWmdDOFVLVk1oWkFEY0ErQW1JbnJBODd6ZXFSNndvYUZoMjJ3MisyRUF4eERSZmlqdFBVeSs3ZnYrK2JwRGpPUTR6aWNBWEs4N3h6RExzdWEzdDdldkdQN3ZkM1VBY3J1bG1YTGZZbTA4SHQreXJhMnRYM2VRWVUxTlRadW0wK2tWS0kwMTBPOUNSUDloNXN1WitZWWdDQXBXNGE2eHNYSExUQ1p6TEJHZHhjdzdGdW84QlRUQXpEVWJlbzBjeDlrWHdMMHd1R0ZrNWlWQkVPeUZ5YzlHVm83alBBTEE1RTFZSWlJNjJQTzhlOGQ2VUVORHc3WmhHRDREb0xKSXVmSnBCWURMczluc2pWMWRYUVZiWDE1Zlg3OTFMQlk3Z1prL0QyRHJRcDJuZ0ZabE1wbDV5NVl0VzZrN3lMRG01dWFxZ1lHQlYySE9mTEVUZk4rL1lmZy8xdTN0bVhTaDMyMVM0dzhBYTlldVBSc2wxdmdUMFhORTlNV3FxcXFkZk4rL3BKQ05Qd0MwdGJXOTR2dit6enpQcXlHaW93R010dW1PcVdZUzBUYzM5Q0RmOXg4RWNGRVI4a3dhRVRVN2puUGlaSjl2Mi9iSk1Pc3o0VDJZK2Z3Tk5mNEFFSWJodDFGNmpmK3pBRDVUWFYyOWkrLzdQeXRrNHc4QW5aMmRMM21lZDFFNm5aN0h6Q2NTMGI4S2ViNENtRjFSVWZGbDNTRkdXckpreVJvQTkrdk9NY0s3cnVkMU93Q05SUXd5Sm1hK1EzZUdrUll1WExnWkVaMnBPOGNFdkVsRVg2MnFxdHJaODd5ZnQ3YTJGbnN5U3VSNTN1TDU4K2N2QUhBbWhuYmhLeFduMXRYVmJYQ09SM1YxOWZjQWpMcTN2Q0YrdkhEaHdna3YzV3RxYXRxVWlDNHNSS0E4U2ltbGZyQ2hCOW0ydlQwQVkwdkhyc2NxSWpyRDkvMmRmZCsvYXF4NURZWFEzZDA5R0FUQjd3SHNEdUFjQUc4VjgveFR3Y3hmYUdwcU1tMk94KzI2QTR5dy9nNUFjM056RlliK3dvMFFpOFUyMktzdnBrd204MWtBRytuT01VNjNaTFBaM1R6UCswbXhQenpXdFhqeDR0RDMvU3ZpOGZpdXpIeWp6aXdUVUJHTHhUWjRyN2kxdFRWTFJNY0RlTE1JbVNacnMydzJPK0Z5dCtsMCtrS1lNeGw0ZmQ0S3cvQjR6L015RzNvZ0VYMEJnSEVWNDBieGgzZzh2cXZuZVZkQzg1SlR6L015dnU5ZllsbldiZ0RHWEYxaGtLcDBPbTFVK1c1bXZrZDNoaEhxYW10cjM5bmw5NTA1QUxadDcwZEVwZ3hWTFBkOTM1aGlSRFUxTlpYVjFkWFB3K3hKWHdDUUpxSnpQTThyV0RHWXFiSnQrNU5FOUV1WTM1bnFKNkx0UE05YnZhRUh1cTU3QmpPYlhDNDRVa28xcFZLcHg4Zno0RnhScE1kaDlvU3cwMzNmMytEU3hNYkd4dXBNSnZOdm1IL3Jib0NJenZJODd4cmRRVWFUdTNaL0JXRFUwdGttWU9aWFpzMmF0WU9HVWM5Uk9ZN3pGSUJkZE9jQUFDTGExL084aDRBUkZ6Z1JtYlNWclVrOUpsUlhWeDhIOHh2L0ZWRVVmZERreGg4QWdpRDRQVE12QkdETWFwTlJWRFB6S2VONVlPN2IycDBGempNVktvcWlYMkI4RGJyQzBONEhKamYrOS9pK2Y5VjRIcGpOWmsrRitZMy9jaUp5VEc3OGdhRnJGMFBMWDBjdHRHUUNJdHF5djcvL0dOMDUxbkdmN2dBanZOUFdqK3dBR0RQOGo2SFoxU2I1ak80QUcvQkVHSVlmbXVxU3IySUpnbUI1SnBQWmc1bVg2TTZ5QWFkaGZCWEdtSWhPeFZEUkZWTWx4ek1oMEhYZFUyRFFYS0QxZU4yeXJKTXd6cFVOelB5cGdxYVpJbVorbklqMk5ySGMrZnI0dnU5Wmx2VkJBL2U4WDllcHVnT3N3NWd2dFZFVXZWTUk2NTBPQURPYlVoMHJqTWZqeG15ODRqaE9IY3orUVB3SEVlMjVvVFhRcGxtMmJObktNQXdQQkhDWDdpeGoyTlYxM2VieFBORHp2RjRpR3JPU29BRitXRmRYTitxdGw5cmEybzJaMmVqdGNZbm9qUGIyOXI3eFBEYVpUTGJBNENKVnpQeDNwZFErbnVlWnZzZkV1N1MzdC9lRlliZ1BnRWQwWnhuREh2WDE5Y2JjUm82aTZCRVlVa2FjaU41NVhSUXdWQ1VLNXV5TTlZUkp5LzhNLzFCdlM2ZlRoNDduUHJXSnVycTYzdXJ2Ny84L0FBL3B6akthaVh5RDlEenZGaUl5Y3VmS25LMWlzZGlvUlk0cUtpck9CdkNlRFVNTWNxM25lZU11RFI1Rmtjblg3b05yMXF3NXl2Tzh0M1VIbVl5T2pvNVZNMmZPUEFSQVNuZVcwVmlXWmN6b1Q2NjZxQ21qUExYRCs1NG9BRml4WXNWT01HZGloekU3S0MxYXRNaUtvdWhvM1RsRzhVdzJtejJpdTd2YjVCbm9HOVRUMDVPT3grTWZBZURyempLS28xcGFXaVpTeE9Nc0FQOHVWSmc4K09yNmRnV3piWHNySWhwekMxM05uby9INCtNdWJad3IyVzFLQ2RaMWRVVlI5TkhjdnZFbGE4bVNKV3VJNkdDWTA3Q3Q2NWl4TnZncU5tWTJaV1I3NXJQUFByc2prT3NBUkZGa3pQMS9JbHFxTzhPd1o1OTlkbThpMmxKM2p2VjRnNWsvWE9qQ0lNWFMxdGJXYjFuV29RQ21YTnEwQUtwWHJWcjFuazAwUnVONTNtcG1ObW9aMGpvMkJ2Q2V0Zk5FOUVPWXZUTGo5SW1NREVaUmRBaUdmbGZUdkJTUHh3OFlhNytKVXVKNTN1dTVhOWVZNm5zanpPM3A2Um5YTGJ3aU1hWnRRMjVETEFXOCs1NkFBVXdxckdMaXQzOG1vaFBIMnZLMEZMVzN0L2NwcFk3RDBGNEZSc2xWTkJ5M0lBanVNcm5tQVRPZjdMcnVPek9CYmR1dUIvQkpqWkhHUkVTLzkzMS9RcE9vaU1pNDNlRUFaSm41dUxhMnRsZDBCOG1uOXZiMkZVUjBDaVpmY3JwZ0pucnRGcGd4bzl2TVhBdmtPZ0FHMVd4LzIvTThVOHBQRWhFZHFqdkVldnpZOHp5VGw1eE5XaXFWYWlVaTR5YWhFZEhCTFMwdEU5cmdTQ24xQlFDdkZTalNWQ2xtSHJtdDhZOWc3cDRHcjBkUk5PYm1UT3R5WFRlT29VMnBUSE51RUFULzBCMmlFRHpQdXdXQWlVdVFEOU1kWUZoTlRjM1RNR1JiZGFYVURzRC9SZ0IyMEpobHBPVXdaS2FrNHpnTEROenk5NW4rL3Y3djZBNVJTUFBtelRzZlFLQTd4em8yZWZQTk55ZTBFc1R6dk5lWmVVSU5WNUh0YTl2MndjbGs4aEFpK3JEdU1LTWhvaThFUVRDaGpoUVJOUU9vTGxDa3lmTG16NTkvc2U0UWhkVGYzLzkxQS9jUDJONjI3US9vRGdFTVZVV0ZJZk1sbUhrSDRIL0xBTGZYRitWZGx1a09NSUp4M3lDWStZeFNuemkwSVlzWEx3NlorWE13cENNNExJcWlneWY2bkZ6aEZHUFcvNjVMS2ZValpyNUVkNDR4M09WNTNvUnZwVEN6YWRkdXBKUTZJOWNBbEsyZW5wNTBGRVhqbnFoWkxFcXBDVis3QmZTRTdnQTVPd0NBeXMyU05HTHJSMlkyNWNVQmdIMTBCMWpIVFVFUW1GS3F1YUNDSUZoS1JLWnNTejFzVXU4SFp2NE1ETjByZ0pscmgrOEZHdWl0YkRiN3VjazhNWW9pMDY3ZHE4ZGJocm5VQlVGd0Y0Qy82YzR4RWpPYjlINHdwWTNiRm9CU3p6Ly8vRll3WktNTUl1clduU0ZId2F4dFVDUFRDN1RrbTFMcVBBQ0R1bk9NNEU1d09TQUFJQWlDRjVqNTNFSUVLbWRFOU0ydXJxN25KdnE4cHFhbW1VU1VLRVNtU2NvUTBRVzZReFFUTTM4YlpvM2c3UUZEU2xzcnBVenBBRlRVMWRWdHBjSXczRUYza2hHZTFSMEFBRnpYcllWWjljUC9IQVRCY3QwaGlxbTl2ZjFGSXJwZWQ0NFJLdGVzV1pPY3pCTnJhbXArRHFBOXozbksyV09lNTEweG1TZXVYYnQySVlDS1BPZVppbXM5enpPNUxrVGU1VDZyYnRXZFk0Uk42dXZyamFnSXljd3JkR2NZVmxGUnNiMWlaaU9HL3dGRS9mMzlMK29Pa1dOVTZkOG9pa3pmbDcwZ21Qa2ltUFZOWWxMdmk4V0xGNGRFZERyTStsMU1GVEh6bVpqa2EwVkVDL09jWnlwQ0lqSjVqa1hCTUxOUm94NUtLU00rMHlzcUtsNkFJY3Nsb3lqYVJzR2NQYi83VEpuZ3hzejF1ak1NWStiSFMyV1RuM3p6ZmI4SFpwVUpycHZzRXozUDg1bjV0L2tNVTQ2STZLb2dDS1pTWHRhWWF4ZkFBNTduR1RHcVdXeTV2ME5qVnZNUTBhU3YzWHhhdW5UcEFET2JVc0R0L1lxSU50T2RJc2Vrd2paR3ZGa0F3TEJoOEtJejdQZWYwdnNpSG85L0hXYnZHS2piU2dCVFhlWnF6TFVMd0tUM3JnNG0vZjRtdlMrTWFPdUlhRlBGekp2b0RwSmp4SXNDQU14c1NtbmtEQkg5U1hjSW5kYXVYZnNYQUcvcHpnRUF6THpiVkdxTFAvNzQ0MjhRMFh2SzhJcDNmR2NxTytQbENnRHRrc2M4VS9GbU5wczFhalo4c2NYajhSc0JaSFhueURIbE14MUU5THp1REFEQXpKc3BBTy9YSFNUSGlQS1lDeFlzMklTSU50V2RJK2V4VXRzcU5OKzZ1N3ZmWk9hSGRlZklxVnl4WXNXVTVzeFVWVlg5QWtCWG52S1VEU0xxcnE2dS92VlVqcUdVMmhibVRBQjhzS3VyeTRpT3F5NjVrc2VtN0JhNHVldTZwa3pzTnVVV3dHYkczQUlnb3YvcXpnQUFGUlVWcHBSRkJvQUhkUWN3Z1ZMS21Ia0FVUlJONmYzUjJ0cWFCZkNsUE1VcEcwVDArZHhyTTJuWmJOYWthOWVZOTZ4bUQrZ09NSXlaalNoNHg4eEd0SFVBTmxNQWpPZ0FNTE1SOTBhSFN5U2FnSm5sUXdRQUVSbnpJVUpFVTI1a2ZOOS9rSWorbkk4OFplS21WQ3JWbW9majdKQ0hZK1NMZE41aDFtZllWRHZ2K2FLVU1xS3RBN0NwQWxDbE93VmdWSzlvSzkwQmNpS2xsS3dkQjVCS3BUcGh5Q1lheUZQVlRLWFVsMkhJM0FiTkJwajVuSHdjU0NsbHlyWDd0dS83cGhSODBTb013OGRneUxJM3k3S01XUEp1eXBkZEFOV0tpSXk0WjJiS0xRQ1lNeWZpUmMvejN0WWR3aEFSZ0I3ZElYTHlNbUxXM3Q3K0lqUC9KQi9IS25FWDUydHI2eWlLakxoMmN4dmlTTTBIQUYxZFhXOFIwVXU2YytTWU10cHRTbHRYb1pqWmxBNkFLZCtHakhpVHdKQmRvd3hpeE91Unp6a3pnNE9EUDJKbUl5YS9hdkxhekprekw4M1h3VXlaejhUTVJyeFhUV0hLNjhITVJydy9BSmp5eGE1Q3daQlpzMFJrU3QxM1U1WkZUc3NDSXFOaFppTkdBSmc1Ynl0RXVydTczd1J3ZnI2T1Y0TE9XN0preVpwOEhjeWdKYzF5N1k1QVJFWmN1d0JNV2QxbFJGdkh6T1owQUxMWnJCRXZDb0FKYi9oU0lDdDFCekFKRWEzU25TRW5yKzhQcGRTdk1BMGJEQ0o2THAxT1g1M25ZeHB4N1JyMFhqVkNGRVdtdkI1R3ZEK1VVa1pVdkNXaVNtTTZBQWFOQUpqeWVoaTVoYXd1UkpTM2I0cFRWSm5QZzNtZWx3RXc3WFlMaktMb205M2QzZm0rNW8yNGRwblpsUGVxRWNyMTJwMHNrOW82NlFDOGx4R3ZCek5MQjJBRVV6NVVtVG52SHlLKzc5OEl3TS8zY1EzV0dRVEJ6ZmsrcUNuem1RREl0VHVDS2RjdURPa0FaTE5aSTBZQUFGUWFzVWN5QUVSUlJMb3pDS0VKQS9pVzdoREZvcFE2R3pKTFhnanRGQXlha0tBN1E0NFJyd2NSYmF3N2cwbUl5SWg2RlVSVWtONjc3L3QzdzZDcWFZWEN6SzJwVk9xK1FoemJvRkZFdVhaSE1PWGFCV0RFTis5WUxHYkVTQVNBdERFZGdIZzhMaDJBRVpoWlBrUkdZT2F5L3hDSm91Z2JNS1JvU29Hd1V1cnJCVHkrRWRldVFRMmVFYWJEdFRzUlVSUVoxUUV3NGtVeGFBUmdyZTRBT2FZc2FUSUNNOC9XblNHbllPK1BqbzZPZGdCM0ZPcjRCcmpWODd5MlFoMmNtWTI0ZGcxNnJ4cEJLV1hLNjJISys4T1V0aTZ0VEJrMk02VlhaRkJGd2hyZEFVeWlsTnBKZHdhZ0tHVTh6ME9aamdKRVVYUkJJWTh2MTY2Wm1ObUlheGVBRVNWNExjc3lvcTBETUtpWTJZZ1JBQ0o2bis0TWdGRjFtazNaMTl3SXpHekU2MUhvalR4ODMvY0FGT1FldVdaMzVVWTRDc21JYTVlSWpIaXZtc0tVMThPZ3ozWWoyanFZTkFjQTVwVGdOZVZOc3EzcnVxYThVWFJUTU9SYlZUSHFlRFB6OXdwOWptSWpvb0orKzgrZHc0aHJsNWwzeHRCN2R0cXJyYTNkbUptTjJJUkhLV1hFQ0ZFWWhrYnNXUUVnclV4Wm8ybEtIVzhBTCtzT2tLT0lhS0h1RUNad1hUY0JZS2J1SERrRjM5Z2tDSUtsek54YTZQTVUwUU9lNXoxUzZKTkVVV1RLdGZzKzI3WVg2QTVoZ29xS2lrWUFSaXp4RHNQUWlFMkpER3JyMWlnQXIrdE9BUUJSRkJueG9paWxudE9kWVZnWWh2dm96bUNJZlhVSEdNYk14WHAvL0xCSTV5azRwVlJSZmhjaU11YmFKU0pqM3JNNm1mUTZHUFRaYmtSYkIrQjFaY3F3R1JFWk1TeVNUcWVmMTUxaG1Fa1hqMDdNYk16clVLd1BrU0FJSGdCUThHL05SYkEwbFVxMUZ1TkVsbVU5WDR6empKTjAzb2ZzcHp2QXNIZzgvcnp1RERsR3RIVUEzakJtQkFEQTVyb0RBTUN5WmN0V3dweDVBSTIyYlJ2eHV1alMzTnhjQldCdjNUbHkxczZiTjY5b3c0ak1YUEQ3NWtWd1hyRk90TkZHRy8wYjVzeHAycWV1cm00ajNTRjBhbWhvbUFQQTFaMGo1OVcydHJaKzNTRnlqT2dBTVBNYkNvWTBkc3k4dmU0TXc1aDVtZTRNT1hHbDFMRzZRK2cwTUREd1VaZ3phM2I1NHNXTHcyS2RMQWlDdXdDa2luVytBbWozZmYrZVlwMnN0YlUxQzhDSXZlY0JiR3haMWxHNlEraVV6V2FQQXhBMVczMkpBQUFnQUVsRVFWVFRuU1BIbE05MEFOaEJkd0FBVUVxOXJreFpHa0ZFTytqT01FS1g3Z0REbVBrRTNSazBNK2IzMTlReC9MR0djK1lGRWYxSXcybU51WFpoMEh0WEI2V1VTYisvTVIwQVp0NVJkd2JnZnlNQXB0d0MyTUtnSVRPVFBrU1NydXM2dWtQb2tFZ2tkZ0xRb2p2SE1LVlUwVDlFcXF1ci93TGczOFUrYng2OFVGVlY5VGNONXpYbTJpV2kvUnpITVdMNWFyRWxFb2tHWms3b3pqSE1sRkhkeHNiR2FpTGFWSGVPbkRjVU01dXlkTWFZVVFETHNncFdyblNTdnFFN2dBNUtxVy9Bb1BYVVlSZ3VMZlk1YzhQYXZ5ajJlYWVLaUM3UFpTOHFaamJwMmxYTWZJN3VFRHBZbG1YVTdwWkVWUFJyZDMwR0J3ZU4rUFlQQUVUMGtySXN5NVNsRWJBc2E1N3VEQUNRU3FXNmkxSHdaYnlZK2Foa01ybTc3aHpGNUxydWRnQ08xNTFqaFBUczJiTjlIU2VPb3VncWxOWWU4MitHWWZnYkhTZWVNV05HTzh5WkNBZ2lPdEcyYldQbU54VkRmWDE5TFRNZnJqdkhDQ3Q5MzM5YWR3Z0FJQ0lqMmpnQWlNVml6eXZQOC9wZ3lDWUpSR1JLSThkRVpObzNpWE4xaHlnbVpqNFBnQ21iWm9DWlU2MnRyVnF1azQ2T2psVUFydE54N3NrZ29tdHptWXR1NmRLbEF3QUNIZWNlUlJ6QXQzV0hLQ2JMc2k2QVFTTjNBSllBaUhTSEFBQWlNcVZBMUZ0dGJXMnZLZ3h0UFBLQzdqUTVwcnc0QVBDUTdnQWpNZlBISE1jNVVIZU9Za2dtazgwQVR0U2RZeVNsbE5iM1F4UkZQNGNoSDJJYndFU2s5WllGTXh0MTdSTFJLWTdqZkZCM2ptSndIT2N3QUVmb3pqR1NZZThISTlvNElub2VBQS8zMGt5NURWQ25POEF3cGRSZHVqT3N4eFV0TFMwemRJY29wSmFXbGhnelh3RkR5b2NPaTZMbzd6clAzOUhSOFF3QXJSbkc2ZlpVS3FWN3VOVzBhMWNCdUtxbHBjV1VKWEVGMGRUVU5CUEF6M1huV0pkU3lwanJocG1ONkFBdzgvTkFicGdtMXh2UWpwbDNNYVdCUzZWU1R3QjRVWGVPZGRTc1diUG1mTjBoQ21uMTZ0WGZNV24yTURDMEFWQk5UYzNqQnVUNG1lNE1HNktVK3FrQkdaWUNXSzA3eHpvV3JGbXpwcXduOHc0T0RsNE13Smg3M0RuUGU1NW5SRzJJWEFmSmxGVWh6d0c1RGtBUjY1dHZTR3pObWpVZjBCMWlHRFBmb1R2RHVwajVTN1p0R3pYRWxpKzJiZTlIUk1iZEx5V2l1NHBaQUdnMHVmTEFQYnB6ak9HWllwWDlIWXZuZVJrQWQrdk9zUzVtUGplWlRMYm96bEVJdG0xL2xKblAxSjFqUFl6NURGKzdkbTB0QUV0M0R1Qi9YL3FIYndFczF4ZmwzWmk1U1hlR1laWmwzYXc3dzNvUWdHdnI2dXFNV1U2U0Q3WnRid1hnRHpCcjhoQUFnSm1OZVI4UWtmYVJpREdZTkhIV21MK3pFYXdvaW03TWxjZ3RHNDdqMUJDUmxsVWY0MkRTKzhDWXRpMktvdVhBLzI0QkdGTThnNW4zMEoxaFdDcVYrZ2ZNMlI3NEhVUzBhU3dXdTdleHNYRkwzVm55b2JHeHNWb3BkU2NSbWZqN3JGcXpaazNSeXRsdVNCUkZSczJOTUZWMWRmWGZBWmhTKzMya3VXRVkzcnRnd1lKTmRBZkpCOXUyTnllaU93SE0wcDFsWFVUMEg5LzNsK2pPTVl5SW1uVm5HQlpGVVJlUTZ3QjRudmR2QUN1MUpzb2hvajExWnhnaEFyQllkNGhSMUdReW1kdHJhMnMzMWgxa0tscGFXbVprTXBuYlRMdnZQOEpmZTNwNjBycEREQ09pUnQwWnhtQk10dHlTelZ0MTV4akZnbGdzOWxkVDVqdE5Wbk56Y3hVUjNjM01PK3ZPc2o1UkZOMEVnMWJPbU5JQllPYi9kbloydmdTOGU3alZpRktKQUxacmFHallWbmVJWVFZUGJRRkFRMlZsNWQ4VGljUnMzVUVtbzdhMmR1UCsvdjViWU01dWYrOFJSWkV4Zi8rNW9XUFRKbG1OdEpQcnVuTjFoeGpHek5mb3pqQWFJbXJwNysvL20wSGx6eWRrd1lJRm03ejk5dHQzQVRDNVRQbHZkUWNZbGtna2RtRG1iWFRuQUFBaTZoeis4OGdPZ0RHM0FiTFpyREdqQUo3bkxRUHdtTzRjWTlqTHNxeEg2dXJxakhoempWZFRVOU9tbFpXVjl3QXd1YmJCVXgwZEhmL2YzcDNIeDFXVmZRRC9QV2NtbVJab3lsWnBDeWh0dzJicEpQZWVwTFVzRWdSWlJCYmhMWXNJaUd3Q2dxQ2d5S3VDS3lLSWJMNEtvcks4SWxCeFo5OVNvY1EyYys5TlV3b1VXb3FBVGNyV0pnV2FTV2J1OC82UktXOW9zMmRtenJrenovZno2VWViWnU3OXRXVG1uSHUyeDRvalJBRWdETVA5VEdjWVNoaUcxa3poQlVId1R3RFBtODR4aUVQajhmaVRVU3Y1cmJXZVVsRlI4YVF0VDdUOVllYUZRUkJZczdaTktXVk5tMFpFejI3OC96YU9BQUQyTlFvM213NHdHR2FlR1kvSG4zSmQxNWJhMjRQU1dzOUtwOVAvQW1CTll6R0FtOUY3VUpZVndqQTh3SFNHb1JDUlZSbHRIZ1hJcVNlaXAycHFhbWFhRGpJY2RYVjFzM1AxRm1wTVp4bU1VdXJYcGpOc3dxWTI3WU9IL1E4NkFFcXBGak5aTmtkRWg4Q2lnMkE2T3p2L0FLRE5kSTRoN0FLZ3lYR2NiOEtpZjd0Tk9ZNXpDak0zQWRqVmRKWWhkQkxSNzB5SDZFc3BkYWpwRE1OZ1ZjYkt5c3BiWWQrWkFKdmFQUmFMcGJUV1h6VWRaREN1NjU0Vmh1RlRBS3lab2gzQTZxNnVyaitZRHRHSEFuQ3c2UkFiWmJQWnphY0FObXpZMEFKZ2c1RkVtNXVzdFhaTWg5Z290d2dzQ2hYWktvam9KNjdyL3RXMkFpU080MHgxWGZkZUlyb2RRQlRtUFgvbGVaNDFEWWZXZWc5YjZvZ1BZVWF1akxNVkZpMWExQm1CVVFBQUdNZk0xN211ZTdkTjZ5aUEzdmxyeDNIdVIrK0ltRFgxT1FaQ1JEY3VXN2JNbW9KUXRiVzFHc0JIVE9mSWVUOFdpMzN3c1A5QkJ5RDNEOVpzSkZJL21ObXFKNGxFSXZGTFJLY2kyeEZFdEV4cmZlbk1tVE9Odm1FYkdocmlydXRlU0VUUEE1aG5Nc3NJcExQWjdBMm1RL1RGekllWnpqQmNSR1RWZXpjZWoxOFBpeW9FRHVGNFpuNWVhMzNCdkhuempCNGFVMTFkblhCZDk3K1ZVc3VJNkRNbXM0eEFaM2QzdDFWVHRyRll6S2IzN3FMY1FWa0FOamwwaFptdDJUTUo0SERUQWZwcWFtcDZCNEJWamNJUXRtVG1LeE9KeEl0YTY2L21qcUVzR3ExMWhlTTRwM1IyZGo0TDRPY0Fxb3A1LzdFZ29sczJicE94UmNRNkFGWTFGczNOemE4UmtUVXJ3b2RoSWpOZnYzTGx5aGUxMWwrdHJxNU9GUFBtTTJmT3JIUWM1NVNxcXFwbkFmd1F3QmJGdlA5WU1QTjFTNWN1dFdKTCswYk1iTlA3NFptK3YvblFYTEhXK25DTGpyOWxacDRXQklFdGxRb3hhOWFzYlNvcUtsNEdFTVZ0ZC84aG9wdDZlbnIrdDdXMTlmVkMzU1EzZlBsNVp2NEtldGNsUk0zN1JGVHRlWjQxYXo1bXo1NjlYU2FUYVVOdmFka282RWtrRXBOem5XWXIxTlRVN0JpTHhWWUFpT0xlKzFlWStjWjRQSDVYYzNOemU2RnVVbDlmdjNNMm16MFp3SGtBcGhicVBnVzBOZ3pENmFaS1VmZEhhLzNSWE9FZFc5WmxIZWI3L2dmSFpIK29PbFYzZC9jekZSVVZJZXc0anBVQUhBdmdXdE5CTmxxNmRPbGF4M0YrUmtRL01KMWxGSFprNWl2ajhmaVBYTmQ5a29qdXptYXpqN1cwdEx3eTFnc25rOG1kNHZINFFlZ2R2dncwTERudmVwUitZVlBqRHdBOVBUMUhFMUZVR244QXFFaW4wMGNDdU0xMGtJMldMRm55SDlkMWZ3bmdJdE5aUm1FWEl2cFpOcHY5cWV1Nmp3QzRONXZOUHBxUFVhcGtNamt0OTk0OU1adk43Zzg3UHZ0SGhZaXV0cW54QndCbVBnSDJOUDRoRVgxb1cvTm13YlRXenpLekxWdFNGdm0rYjFVZDdibHo1NDVQcDlNdkFQaW82U3g1OGpJUlBjbk16d0o0SVpQSkxLK29xSGk5N3p6UlJnME5EZkdPam80ZGxWSzdoMkc0T3hIdFJVUU50cDRFTmdwdkVORnVOaTMrQXdEWGRSK0NYZHVJaHNUTUR3UkJZTlUwWG00RTcwVUEyNXZPa2lmTEFTd0FzSlNJWGd6RGNQbkVpUlAvMDlqWW1ObjBHN1hXRlVxcG5iUFo3RzRBOWdBd2k0Z09pTWpDMGlFUjBhb0pFeVo4UEhjQ3BEVmMxL1ZnejJGSlMzemYvOUNKcTV0MUFGelh2UkhBVjRvV2FYQ2NHOUo1eFhTUXZoekhPWUdJYk5wbVVnaHA5QzU2N0VEdi9QMVdpT2J3NlVpYzVmdStWZnVINTg2ZHUyMDZuVzVIZEliL04rb093M0FIMjU3SXROYm5Nbk1VZHZTTVJSZDYzN3VkNkQyamZ5c0FSVjFIVUd6TVBDOElnaithenRHWDY3clZBRjR5bmFPUDYzM2Z2N0R2RnpZYjdpRWltOHBva2xMcUpOTWhOaFVFd1QzbzdYbVhzZ1NBN2RCNzlPejJLUDNHUCtYN3ZqWEgvbTdVM2QxOVBLTFgrQU5BcFZMcWVOTWhOalZod29SYmlNaWFNMDhLWkJ4NjM3UFQwZnNlTHVuR0g4RGp0algrT2JhMVhadTE3WnQxQUNvcks1K0FQZWNCZ0loT2gzM3pVcHpOWnMrQ1JmOU9Za3d5UkhRMkxDb2NzaEV6bjI0Nnd4aWNaanJBcGhvYkd6UFpiUFkwQUp0TmNZbEkyZ0RneTZaRDlFUEJycC8vRFlsRVlyT0gxczBhMXFhbXBnMEFuaXBLcEdGZzVtbDFkWFVIbXM2eHFTVkxscnlJM2kweUl1S1krUnJQODN6VE9UYWx0WjRGSUJMSE93OWdUdTd2WUpXV2xwWVdBTmViemlIeTRncmY5MWVZRHJFcHgzRU9BV0RUWVd5TnViYjlRd1o2c3JacEdnQmhHSjVwT2tOL2lPaHFabDVzT29jWVBTSmFObTdjdU8rYnp0R2ZNQXpQTUoxaHJKajVGTk1aK2tORWw4UHVRa0ZpYVArcXFxcXlacGRZWDBSazFYdVhtUi9zNyt2OWRnQ1VVZzhVTnM2SUhaVk1KbTA1U3ZFRG51ZjFLS1UrRDJDOTZTeGlWTkpoR0o3VVg4L1lOSzMxRmdDK1lEcEhIcHhxWTkxN3ovUGVWMG9kaDk0RmN5SjYzZzNEOEpUK2RqeVlObWZPbkIwQUhHRTZSMS9NM085RGZiOGRnRlFxdFJ6QXlvSW1HcG5LZUR4K2p1a1EvZkU4YnlVQXE0dDRpUDRSMFRlQ0lGZ3k5SGNXSHpPZlRFVGJtczZSQjVNNk9qcHNXd3dGQUVpbFVzOFMwYmRONXhBang4em50YlMwMkxUQy9nUGQzZDNud3E2RnV5OE45RzgxNE9JNklySnRWZVY1eFQ3T2RyaDgzLzhkRVZtM2dsd002aStlNTkxb09zUWd6ak1kSUYrSTZFTFljeGpLaDNpZWQ2MkZuM1ZpY0xjRVFYQ0g2UkQ5MFZwdlFVVG5tczZ4aWZrRC9jRmdxK3Z2TFVDUXNaaVVUcWV0bkU4RWdBa1RKbndGUU1wMERqRXN5eXNxS2s0RndLYUQ5RWRyZlRBQTZ4YlBqY0ZlV3VzRzB5RUd3T1BHamZzU2dPZE1CeEhERWlRU2lRdUgvall6bVBrMDJIZlExRDBEL2NHQUhZRGNxbWpiaGxndWduMWJBZ0VBalkyTlhXRVl6bVBtTmFhemlFR3RWVW9kdFdqUm9rN1RRUWJDekY4em5TSGZtUG5ycGpNTVpPSENoZXVaZVI1NkQ3MFM5bXFQeFdKSDJiaG1Cd0J5MVJ0dDY1d3M5MzIvZGFBL0hLb3h0VzBVWUhmWGRZODJIV0lndVJNTFB3dmdQY05SUlA5Nm1IbGVibzJMbFdwcmErc1JzV04vaCtreldtdGJqa1RkVEJBRXp5bWxqa1oweWdhWG13MUVkSFJ6Yy9OcnBvTU1aT1hLbGNjQ3FEYWRveTltSHZEcEh4aWlBMEJFZzc3WUJDTDZQaXdkQlFDQUlBaFNBRTZHaFlmS2xEbG01dE9ESUhqY2RKREJLS1crWXpwRGdSQXovN2ZwRUlOSnBWS042RDFVeHNxcG9US1daZVlUUE05YlpEcklJQlFBR3hlVWpyNEQ0SG5lVWxpMlY1YVpaN3F1Tzg5MGpzSDR2djluQUtkRFBraHM4czBnQ080MEhXSXd0YlcxdGVnZFFTcFZuNnVycTl2TGRJakIrTDcvT3dBbE53VVRZUXpnbkNBSS9tWTZ5R0JjMXowUjlxM2JlVFlJZ2tIWHRnejVKTTNNdCtjdlQ5NWNrWnR2c1pidis3Y3hzMndQdEFBUmZkZjMvYXRONXhpS1V1cHlXTHBhUGsrSW1TODNIV0lvdnU5Zng4eFdIZzVWYm9qb0V0c0tkRzJxb2FFaERzQzZuMnNpR3JMdEhySURVRmxaZVJ2c096ZDdqeFVyVmxpNXQ3aXZJQWh1SktKTElDTUJ4aERSRHozUCs0SHBIRU9wcmEzZEc0QzE2MXZ5aFptUDFWclBNWjFqS0VFUVhNN01WNXJPVWNhWWlDNzJQTzlucG9NTXBhT2o0eFFBdTVyT3NZbnVNQXpIM2dGWXRHalJHZ0IvejB1a1BGSksvU2laVEc1cE9zZFFQTSs3QnNBNWtEVUJSVWRFbDN1ZUY0azVkU0w2cWVrTVJVTE1iUDFvREFBRVFYQVpNMTlxT2tjWllpSzZNQXFOLzh5Wk03Y2lJaHNmTVA0U0JNR2JRMzNUY0JmVFdUY0V3OHc3eGVQeFMwem5HQTdmOTIvTzdRKzFiU1NsVkdXSjZGelA4eUl4akt1MVBwcUk5akdkbzRqMmMxM1hxcU5TQnhJRXdWWE1mQUdrQTE4czNRQk85anp2QnROQmhpT1JTSHdMd0ZUVE9UYWxsTHAxT044MzNQbEc1YnJ1U2dDN2pEcFJZYndmaThYMnNIbHJTRit1NjM0S3dIMEF0amFkcFlTOUIrQkUzL2V0RzdYcXo4eVpNeXNUaVVRcmdOMU5aeW15RjlMcGRNMnlaY3Npc2UxT2EzMDBNLzhld0JhbXM1U3d0VVIwck9kNVQ1b09NaHpKWkhKYVBCNS9Eb0JWdFM2SWFKWG5lZFVZUnFkMXVDTUFJVFBiZU5UdEZtRVlYbVU2eEhENXZ2K0VVbW8vQUsrWXpsS2kvZ05nLzZnMC9nQ1FTQ1F1UnZrMS9nQ3doODBudW0zSzg3eS9LS1VPQU5CbU9rdUplaG5BUGxGcC9BRWdIbzlmRGNzYWZ3REl0ZFhER3JFYTluNzZlRHgrSzREMGFFTVZDak9ma0h1eWpvUlVLdlZzSXBIUUFCNDJuYVhFUEVWRTliN3ZlNmFEREpmak9COERZUFhlK0FMN1RuMTkvYzZtUXd4WEtwVmF6TXcxQUNMVFNFWEVnNGxFb3Q3M2ZhdTJuQS9HZGQxREFCeHJPa2MvMHJGWWJOZ1A2OFB1QURRM043Y0QrUDJvSWhVV0VkR3RVVmdRdUZGVFU5TTdNMmJNT0J6QWp5QnppMlBGUkhSdFZWWFZwenpQaTlUVG1WTHFlcFQza1BKVzJXelcrb1ZlZlFWQjhDWVJIY0xNTjBCMjk0eFZGc0QzZk4vL2JGTlQwenVtd3d4WHJsVDMvNWpPTVlBN2NtMzFzSXhvejdIV2VnOW1YZ1k3VCtMN3FlLzczelFkWXFTMDFnY0F1SU9aZHpLZEpZTGVBSEM2Ny92L01CMWtwQnpIT1pLSS9tbzZoeVdPeVIyZUZTbGE2NE9aK1RZQVUweG5pYURYbVBua0lBZ1dtQTR5VXE3clhvdmV1alMyWVdiZWE2akRmL29hOGFFanJ1cytBT0N3a2I2dUNESUFQaEdsSWVDTjVzNmR1MjA2bmY0RmdCTk1aNG1RdjJVeW1UTmJXMXZmTUIxa3BHYlBucjFkVDAvUE1pTGF3WFFXUzdRbEVvbTlvdlFVdUZGOWZmM2tiRGI3YTVUMkNZNTV4Y3gzTWZONUxTMHQ2MHhuR2FuYTJ0cDZwVlFUQUJzUG92dTc3L3RIanVRRkkzNlNaMlpiaCt6aUFINWJYVjJkTUIxa3BKcWFtdDd4ZmY5RXBkVGhBRjQxbmNkbXpMeUdtVS8xZmYrb0tEYitBTkRUMDNPRE5QNGZNcVdycSt0YTB5RkdvN201dWQzMy9TT0k2RGowamtpSmdhMEdjRXdRQkNkRnNmRnZhR2dZcDVUNkxleHMvRWZWTm8rNEE1QXJwaEtNOUhWRmtxeXFxb3JzNlYycFZPcUJpb3FLV1FDdWc1d1pzS2tzTS84eWs4bnNHUVRCSGFiRGpGWnV6Ly9uVGVld0RSR2RxclUrM0hTTzBmSThiMzQ4SHY4NGVzOU15WnJPWTVsdVp2N1orUEhqOTRqaVZNOUdIUjBkVndHd3RaWkZhalRUS2FNNmQxeHJQWStaYlNzVnZCRVQwYUdlNXoxaU9zaFkxTlRVN0JhTHhYNEl3T3JDUjBYeUpETmZGQVRCRXROQnhxS21wbWJIV0N6V0FtQjcwMWtzOVVZc0Zxc1p5U0ltRzdtdXV5ZUFuNk0weXpxUDFHUFpiUGJDSlV1V0xETWRaQ3djeHptTWlPNkh2YlU2UnJXT1pyUi9HZEphKzh4Y084clhGeFF6cjZtc3JLekpIV01jYVZycmZjTXcvQUVSTlpqT1lrQnI3aXovK2FhRDVJRnlYZmNSQUFlYURtSXpabTZzcnE0K2FQNzgrWkYvaW5ZYzV5QWl1aEpBbmVrc0JqUXg4M2RzTDc4OUhJN2pUQ0tpVmdDVFRXY1pnTy83ZmgxR3NTdGx0S3Y1T1p2TlhqSEsxeFljRWUzUTNkMzlXOWk1VzJGRVBNOTdPZ2lDQTVqNU04eTgwSFNlWW1EbXhXRVlIdTM3Zm0ySk5QNXdIT2N5U09NL0pDSnFXTEZpeGNXbWMrUkRFQVNQK2I0L0c3Mzd4U08zT0htVW5nSndxTy83ZTVkQzR3OUFFZEdkc0xmeEJ4RjlGNlBja2pxVzRReHlYWGNSZ1BveFhLUFF2dWY3L2hXbVErU1Q2N3FmSUtLdk0vUG5ZT2xpbEZFS0FkelB6TmNFUWZCUDAySHl5WEdjL1lub01mUXVWQlZENjFGS0haQktwVXFxdzF0WFY5Y1FodUhGNk4xRkZmbUhrejZ5QVA2a2xMb21sVW90TmgwbW43VFdQMkRtYjV2T01ZaC8rYjQvZDdRdkh0TjhSbTVlNUlHeFhLUEFHTUN4VVY1NE1oQ3Q5WlF3REU4aG9yTUFURGVkWnd4V0U5R2RTcWxibXB1Ylh6WWRKdC9xNit0M3ptYXpLUUFmTVowbFNwaDVUVGFicld0dGJYM2RkSlo4U3lhVE84VmlzWk9JNkJ3QUh6T2RaN1NJNkhVQXZ3L0Q4SmRCRVB6YmRKNTh5eFdzK2dzczdxd3g4NmVESUhoc3RLOGY4NElHMTNVWEFQamtXSzlUUU9zQTFQdSt2OEowa0FKUld1djlBUnpIek1jQ21HUTYwRkNZK1IybDFKK0o2SjVwMDZZOVVRcnp2ZjFwYUdnWTE5SFJzWUNJWnB2T0VsSC82dXpzYkZpeFlvVjFSNURuUTBORFE3eXpzL05BQU1jRE9CckFOb1lqRGNjYnpId2ZnSHVDSUhnS0pYcVNhVzF0N2E1S3FXWUFFMDFuR2NUVHZ1L3ZONVlMakxrRFVGZFh0MDhZaGsvbDQxcUZRa1RMc3Ruc3ZsSGNlem9TdVErVVR3STRqSWdPWSthWnBqUDE4UUtBQjRub0lRQlBlcDVYOHRzY1hkZjlMWURUVE9lSXVGLzd2bitXNlJDRmxxc0tlUUQrLzcyN20rbE1mU3dGOEJBUlBUaDkrdlIvbG1xSGZhTlpzMlp0VTFGUnNSREFucWF6RElLSmFLN25lWXZHY3BHOE5OcGE2N3VZK2NSOFhLdUFGblIyZGg1U3FrOFQvYW1wcWRsUktmVkpJdG9id0Q3bzNjTmFVWVJiWndBOHg4d0xpV2doRVQzbGVWNVpIWENrdGY0V00vL1lkSTVTUUVRWGU1NW42d0ZrQlZGYlc3dUxVbXBmSXRxSG1mZEJiMk5VakRVa1BRQ1dFdEZDWmw3SXpFOEZRYkM2Q1BlMWd0YTZncGtmaE9VTGRvbm9Ecy96VGgzemRmSVJKcGxNN2hTUHgxOEFZSFZCSGlMNmcrZDVKNkZNaTNqa2ZyajNCREFMd0o3TVBJMklkZ0V3RGIxNzAwZlNPY2dBZUF2QUswUzBLZ3pEVndDOEVJdkZscTVidCs2NWN1cG9iY3AxM2VNQS9BRVd6eDFHREJQUkZ6elB1OHQwRUZPcXE2c1RFeWRPbkFsZ1ZoaUd1eFBSTlBTK2J6K0czdmZ1U0RvSFBlaDk3NjRDc0lxSVZnRjRucG1mSmFMbnkyRjBiZ0NrdGI2Tm1VOHhIV1FJN3pMejd2bm9tT1Z0Mk41MTNTc0FYSjZ2NnhVS0VWM3VlZDczVGVldzBadzVjNnJDTU53K204MXVBd0RNdkNXQXlsZ3NsZ25EY0gzdTJ6cUk2RTNQOHpyTUpiVlhic1gvd3dCc1A1SzZFMEFWQUJCUkp6TlhHYzR6bEs0d0RBOXNhV2w1eG5RUUcybXRKekx6Sk9UbXJKVlNFN0xaYkJ4QU54RzlCd0NaVE9hZDhlUEh2NzFvMGFKT2sxbHQ1VGpPOTNKYjZtejNiZC8zZjVTUEMrV3RBNkMxM29LWlh3QVFoZnJlWC9GOS94ZW1RNGpTVWx0Ylc2dVVlaExBMXFhekRLR0htYS9jK0dISHpOOG5vc3RnL3piRnQ0bm9BTS96bHBvT0lrcUwxdm9DWnI3ZWRJNWhlS1dxcW1yUHhzYkdybnhjTEc5RGxKN252Yy9NVVNuSGU2UHJ1bDgwSFVLVUR0ZDE5MVJLUFFMN0czOHc4dzFLcVdzQmJBRFF4Y3cvQjNDVDRWakRzUjB6UDFKYlc3dXI2U0NpZERpTzh5Vm12czUwanVGZzVrdnkxZmdEZVo2akRJTGdEd0FlenVjMUM0UUEzT280anBUZkZXT210ZjRvZ0ljUWdTMllBTnFWVWovSVRlSDhIY0JmVzFwYTFvMGZQLzY3NkszV1pydkpzVmpzaVdReU9jMTBFQkY5cnVzZVEwUTN3K0pkYkgwOEdBVEJIL041d2J3dlVnckQ4TXNBM3N2M2RRc2dSa1IzdUs3N09kTkJSSFRWMXRidUFxQVJ3RWZOSmhtMkN6ZXUzMUJLM2M3TXR3UEF3b1VMMXdQNGh0Rmt3OFRNTzhYajhVZHpIUzhoUnNWMTNXTUEzQTM3cDc0QVlIMHNGanM3M3hmTmV3ZWdwYVhsRlFBMkg1M1lWd1dBZTEzWFBjbDBFQkU5dWNOQy9zbk1VWGthZmNUMy9YczIvbWFycmJaNlpPTEVpWTl1L0wzdiszY0JpTXI1N1RPWStaOWE2eG1tZzRqb2NWMzNDd0R1UVhHMlJlZkRaYzNOemEvbCs2SUYyYWJrKy80TkFLS3lXamNPNEU3SGNjNDNIVVJFaDlaNkQ2VlVJNkt4NkJVQU9vbm96TDVmYUd4c3pEUTJObWI2ZkluRE1Ed0R3SHBFdzhlWStlbWFtaHFiRHJ3U2xuTmQ5MndBdHlNYVQvNEFzR2pHakJtL0xNU0ZDN1ZQT1NTaUw2TjN2MmtVRUJGZDc3cnVSYWFEQ1B2VjF0YldNL00vQVV3MW5XVUVMaG5PWVV3dExTMnZFTkdseFFpVUo1T1ZVbzlyclYzVFFZVDlYTmU5Qk1BdkVaMHpPcnF6MmV6cGhUcDlzV0RWNU5yYTJ0NllPblVxQVRpZ1VQZklNd0p3eUpRcFV5YTJ0YlU5aWpJOUxFZ01ycTZ1N2pNQTdrY0VWdnYzOFpqdis4UHUzTGExdGFVbVQ1NjhmKzZRS09zUjBWWUFUcG95WlVyUTF0WldxalUveEJqTW16Y3Zsa2drcmlPaWJ5TWFDLzQydXJ5bHBlVytRbDI4b0wwZ3ovTitDR0JCSWU5UkFCZTVybnVmMW5vTDAwR0VYVnpYL1dJWWhuK0I1U2RlYnVLOTNPS2hrWFJvbVpsUEEvQnVnVElWd2xZQS9wRWIzaFhpQThsa2NzdVhYMzc1UGlLNndIU1dFWHA2eG93WlB5bmtEUXBkVDU0blRacTBRQ2wxR3V3L0dhMnZQUUFjTkduU3BMK3RXYk1tQ2pzYVJHRXB4M0YrVEVUWG9QRHZtYndpb3ZOU3FkU0lGL2ExdDdldm16eDU4bG9pK213aGNoV0lBbkQ0bENsVEt0dmEyaG9obzNobHI3Nitmbkx1Wk01UG1jNHlRdXVZK2VESEgzOThiU0Z2VXBTaEVNZHhUaWFpTzRweHIzeksxYnYrcjdGV1hCTFJ0YzgrKzB6bzZ1cTZrNW1QTXAxbHBJam9qNTduelJ2TE5Welh2UnU5NVdxajVzRXdERDlmNmhWQXhjQzAxbTZ1ZFBFdXByT01GQkdkVkl6YUYwVlpDQkVFd1ozTUhMbENIc3k4RXpNdmNGMzN6S0cvVzVTYW1wcWEzVFpzMkxBb2lvMC9nTmNxS3l2SFBCeWVPOWZqMzNuSVUyeUhLYVVXTzQ3emNkTkJSUEU1am5NS016K05DRGIrQU80c1Z1R3JvcTJFWk9iekFMeFNyUHZsVVFMQUxhN3IzbHhkWFIybGFRd3hCbHJyejhkaXNSVHNyZ2sra0F3ekg5L1UxUFRPV0MvVTB0S3lqb2krQUNDS05lQjNKYUltMTNXak9JSWhScUdob1dHYzY3cS9JYUxiQVl3M25XY1VWbFpVVkh5bFdEY3I2bXBJeDNGcWlPZ1pBRkZkWVBjc0VYMWVpcEdVcm9hR2huRWRIUjFYUlhEQjBBZUk2RExQODY3TTV6VmQxNzBjd0JYNXZHYVIzWm5KWk01cGJXMlZOVDBseW5YZFBRSDhIb0JqT3Nzb2RSSFJQcDduK2NXNllWSDNRZ1pCc0FUQWVjVzhaNTd0eGN6L2twWEdwVWxyUFd2OSt2V3BLRGYrQU83M1BPK3FmRjkweG93WlB3VHdTTDZ2VzBRbngrUHhKamswcUNTUjF2cGNBQjZpMi9nRHdKbkZiUHdCUS9zaEhjZjVIeUk2eDhTOTgraHZ6SHhHRUFSdm1nNGl4cWFob1NHK2Z2MzZTNWo1Y2tScnQ4cW1YZ3JEY0hhaEZyN05uVHQzMjNRNjNReGdlaUd1WHlScFpyNjh1cnI2bWtJZHJpS0tKNWxNZmlRZWovOEdRSlIycS9Ubkp0LzNpMzRhclpFT2dOYTZncG1mQUxDdmlmdm4wVm9BbC9xK2Y0dnBJR0owdE5Zem1QazJSUDluOFYybDFOeFVLdlZzSVcvaXVtNFN2Y2Q4Uitrc2hQNHNJcUl2ZXA3M2d1a2dZblMwMXZPWStSZUlSaFhPd1RTbDArbUdaY3VXZFJmN3hzWk9SS3FwcWRsUktlVVIwUTZtTXVUUmc4eDhUaEFFVVZ3dFhaYXFxNnNURXlkTy9BWXpYd1pnbk9rOFk4VE1mRnkrUzRVT3hIR2NFNGpvTGtUclJMWCtiQUR3bzNRNmZiV0pEMTh4T3Nsa2NsbzhIdjhWZ0lOTlo4bURObWF1QzRMQVNDbHVvMi9ndXJxNjJXRVlQb25vTGdyczYxMEEzeVdpbXp6UGkwb05oTExrT002QlJQUUxBTHVienBJUHpIeGxFQVNYRmZPZXJ1ditGTUFseGJ4bkFiMUFST2Q2bnZlazZTQmlZRnJyQ2dCZlplWXJFUDBSS0FCNGo1a2JnaUJJbVFwZ3ZBZnZ1dTduQVB3UjBTbk9NSlRuQVh6TjkvMkhUQWNSSDVhckgvOFRaajdSZEpZOHV0ZjMvUk1CaEVXK3IzSmQ5MTRBeHhiNXZvWENBTzZLeFdMZktrVFpWVEUyV3V2REFWekx6QmNmWTA0QUFCZkZTVVJCVkx1WnpwSW5XV1krSmdpQ3Y1a01ZYndEQUFDNUtuelhtczZSWjQ5bHM5a0xseXhac3N4MGtISTNjK2JNclJLSnhNVUF2b0ZvN2czdUZ6TXZWa29kNEhuZSt5YnVQM2Z1M1BIcGRQb3hBSHVidUgrQmREUHpyNVJTMy9VOHI4TjBtSEpYVTFPeld5d1creG1pdjhqdlE0am9xNTduM1dBOGgra0FHN211ZXlPQW9oMkFVQ1E5QUc0am9oOE9weFNyeUsvcTZ1ckVoQWtUemlLaTd5RDZDNFUraEloZWpNVmlleTlldlBodGt6a2N4NW1VTzl1ajJtU09BbmdEd0E4Nk96dC92V0xGaXJUcE1PWEdjWnlQS2FXK3c4eW5Bb2lienBObjE0MmtPbWNoV2RNQm1EZHZYbXpseXBWL0FuQ2s2U3dGa0FidzY5eGNyWkhGSHVXa3VybzZVVlZWZFFZUlhjck1PNW5PVXdCdkV0RmN6L05XbWc0Q0FMVzF0YnNxcFo0QnNMM3BMQVh3R2hIOXBLT2o0emZTRVNpOG1wcWFIV094MkdVQXpnQlFhVHBQQWZ6WjkvMy9RdkduN1BwbFRRY0ErR0JJOFIrSVh1V200ZHBBUkxmMjlQVDh2TFcxZFpYcE1LVW1tVXh1R1kvSFR5T2liNVpvd3c4QW5jeDhvTW1GUS8zUldzOWg1a2NCVERDZHBVQmVBM0FWRWYzTzFKUkxLY3R0eDcwSXdPbUkvcTZjZ1R4V1ZWVjFSR05qWTVmcElCdFoxUUVBQUszMUZzejhFSUQ5VEdjcG9CREFBOHo4NHlBSW1reUhpYm81YyticzBOUFRjdzU2cDVDMk01Mm5nRFl3ODJGQkVDd3dIYVEvZFhWMSs0UmgrREJLWTRYMlFEcVkrZlpzTm50MWEydnI2NmJEUkYydVl0K0ZBRTVFNlEzMTk5V1VUcWNQWHJaczJidW1nL1JsWFFjQUFHcHJhN2RXU2oyQmFCL3JPRnhQRWRHdkpreVk4Q2ViZW9aUm9MWGVsNW5QQm5BY1NuTzRzSzgwRVIzcGVaN1Z4L0U2am5NWUVmMEY1ZkhmNDU1c05udHpTMHZMTTZiRFJFbERROE80enM3T1l3RjhHZEUvZ0dzNFBDSTYwTVpGcFZaMkFBQkFhNzA5Z0VabUxwZXp1OWNCdUplWi95ZFhNMEgwSTljNVBBNjlOU1dTcHZNVVNaYUlUdlE4Yjc3cElNT2h0VDZhbWVlanRKL28rbHJPekw5VFN2M0c4N3kzVElleGxkWjZEd0JmWk9iVFVacnJSZnF6dktLaVl2OUZpeGF0TVIya1A5WjJBQURBY1p5cFJQUUVTdVRBbGhGWUJPQ2VUQ1l6WDRZWmUrZjJZN0hZa1VSMEFvQkRFTzN6K2tjcXc4d25CMEZ3dCtrZ0krRzY3a2tBYmdjUU01MmxpTkpFOUZBWWhuY3JwZjRtYXdXQSt2cjZuVE9aekR3QXh4UFJiTk41aW13NUVSM2dlVjZiNlNBRHNib0RBSHd3di9zb2dGbW1zeGdRQW5pR21lL05ack4vTHFmT1FPNUoveEFBbndOd0JFcmp0TWlSNmdad291LzdmeklkWkRSeVo3WC9Ia0NGNlN3R3ZBZmc3d0QrVEVRUDJ6ajhXeWoxOWZVN2gySDR1VEFNanlPaXZSR0JkcVlBbGxSVVZCeGk2NVAvUnBINEQ1T3JRdllRZ0hyVFdReHJCZkFRRVQwRTRPa1NPM0tZYW1wcVBoNlB4dzlqNXMrZ2R4Rm91UXdoOTZlTGlQN0w4N3o3VFFjWkM4ZHhqaVNpZTFGZW96YWI2Z0h3RkRQZkQrQ2hJQWllUisvSmd5Vmg1c3labFlsRVlsOEFod0k0RE1CZWhpTVp4Y3lMTTVuTW9VdVhMbDFyT3N0UUl0RUJBSUE1YytaVTlmVDAvQU9sdlR0Z0pOWXo4MU5FOUF3elA2MlVhbzdTa09POGVmTmlMNy84OHNmRE1Hd2dvdjBCZkJJbGRsalBHTHpIekVjSFFmQ1k2U0Q1NExydUlRRCtqQkk2aFhHTTNnQ3dBTUFDcGRTQ2FkT21QUitsMHNSYTZ5M0NNS3dIc0YvdUNYOC9BRnNaam1XTEJlUEhqejlpNGNLRjYwMEhHWTdJZEFDQUQ3WUkvaG1sVVFVcTMzb0FlQUI4QUsxaEdDNU5KQkxQTGxxMHFOTndMbFJYVnllMjNucnJYWms1eWN6MUFPclF1OE9qbExlTGpkWTZBRWY2dnYrVTZTRDU1RGpPL2tUMFZ3QVRUV2V4MExzQUFnQXBJa29SVWV1NmRldGVzdUhnb1RsejVsU2wwK205bEZLem1MbUdpRndBTHNweldtY29EeVVTaVdPYW1wbzJtQTR5WEpIcUFBQWZuUEwyR3dBbm1jNFNBVXhFcnpEejh0ei9yaUtpVmRsczloVWkrcy82OWV2Znp0ZUhUSDE5L2VTZW5wNmRsVkk3RWRIT0FEN0d6THNEMkFQQUxpaXZ4V0NqOVZvMm16MnNWT3RIYUsxbm9mZjhpMUk5cENtZnNnQldBWGlCbVpjcnBWNEY4R29ZaHEvSDQvSFhtNXViMi9OeGs5eHgyZHN4ODQ1S3FXa0FkaUdpYWN3OGpZaDJZK1pwK2JoUHFXUG0yN3U3dTgrS1dsbnB5SFVBY3NoeG5PL2x6bmdYWTdNZXdOc0EzZ1RRQVNDVCt4clErMlRTZzk2Zms2MXpYMVBvZllxYkNHQWJadDZXaUxaQmRIK1diUEZ1SnBQWnM5UVhldTYxMTE0N1YxUlVQRWRFTW1ROE5nemdIUUJyYzc4NmlHZ2RNMjljVzdBdTl6MFYrUC9oK1Fub1hWZXpOWHFuMjdhREROMlBGUVA0bnUvNzMwY0UxM1ZFZFpFVkIwSHdYYTMxU21hK0JhVi82RWdoVGNqOTJtVTBMeWFTZGo5UHRxcW9xRGdHZ1BFS1lZV1VTQ1NPWVdacGRNYU8wTnVBZjNEeTVmKzMvYUpJdXBuNWpDQUk3alFkWkxRaS8rbnRPTTZCUkhRZlpHNVJSRitYVXFvK2xVbzlhenBJSVdpdDkyQm1IN0lZVUVUZldpSTYxdk84SjAwSEdRdGxPc0JZQlVId2VEYWIzUWZBUzZhekNERkc0OEl3dkYxclhYSUxyQm9hR3VKaEdONE9hZnhGOUMwbm9yMmozdmdESmRBQkFJQWxTNVlzR3o5K3ZBWnduK2tzUW95Ukc0Ymh0MDJIeUxlT2pvN3ZsdUZKY0tMMC9EME13MDk0bnZlQzZTRDVFUGtwZ0UyUTR6amZJS0lmUVZhZGkraktBTmpQOS8xL21RNlNENjdyYWdCTmtLMWpJcnF5QUg2WVcrd1htZzZUTDZYV0FRQUFhSzBQWU9hN0FYekVkQlloUm9PSVhnVGdST2x3cC81b3JiY0FFRER6YnFhekNERktieFBSNTIydnhEa2FKVEVGc0NuUDg1N01aREtmQUZBU1QxQ2kvRER6YnN4OHRla2NZeFdHNFRYUytJc0llNGFaZFNrMi9rQUpENU92V2JObTNlNjc3MzU3VjFmWCs3bWpaa3YyN3lwS1Z0Mk9PKzdZdkhyMTZrZ3VjSzJycS9zMGdPdFJvaU9Ob3FSbGlPaHFJanJWOS8xM1RJY3BsTEo0WTJxdDkyWG1PekhLdmU1Q0dMUTZIbzhuRnk5ZS9MYnBJQ09ScStiWUNtQm4wMW1FR0FraVdoV0c0VWxCRURTWnpsSm9KVGtGc0NuUDg1NnVxS2lvQVhDTDZTeENqTkRVVENZVHVaOWJwZFN2SUkyL2lKNzUzZDNkdWh3YWY2Qk1SZ0Q2Y2wzM09HYStnWWgyTUoxRmlPRWlvcE04ejd2TGRJN2hjRjMzSkFEL2F6cUhFQ1BRenN6bkIwSHdSOU5CaXFuc09nQUFNSGZ1M0czVDZmVFBBSnlLTXYwM0VKSFRRVVJKei9OZU5SMWtNRFUxTlRzcXBWcUphRnZUV1lRWUJpYWkzM1ozZDEreWRPblN0YWJERkZ0Wk4zNk80M3lTaUc0QnNMdnBMRUlNdytPKzczOGE5aFlkSWRkMUh3QndxT2tnUWd6RHk4eDhkaEFFajVrT1lrcFpyNHh2YjIvLzk5U3BVMzhMSUFHZ0htWCs3eUdzTjMzeTVNbHZ0N2UzTHpZZHBEOWE2d3NBbkc4Nmh4QkQ2Q0dpYXhLSnhQSE56YzB2bWc1alVsbVBBUFNWSzFUeWM4alRpN0JiVnphYnJWdXlaTWt5MDBINmtrSS9JaUx1VjBwOVBaVktMVGNkeEFiU0FkaUU0emdIS2FXdVkrYVpwck1JTVFDZmlEN2hlVjZQNlNCQWI2R2ZqbzZPaFhMV3Y3QlY3bVROcjNtZWQ3L3BMRFlwaTIyQUk1R2JEM0lBbkEzZ0xjTnhoT2lQeTh6L2JUckVSaDBkSGQrUnhsOVlhaDB6WDlyVjFUVkxHdi9OeVFqQUlHYlBucjFkTnB1OWhKbS9BbUJMMDNtRTZDTkRSUHQ2bnJmSVpBZ3A5Q01zOVM0ejN6aHUzTGhybXBxYVN2WWt2N0dTRHNBd2FLMjNCM0F4TTE4QW1lTXNGMjhDbUdRNnhCQldwdFBwMm1YTGxyMXI0dVphNnkxeTgvNjI3NkpwQnpEWmRBaFJGTjBBYm92RllwYzNOemUzbXc1ak81a0NHQWJQODk3eVBPL1NUQ2F6Q3hGZEJhRExkQ1pSTUUwQWpreW4wOU1CckRRZFpnZ3pFb25FVDB6ZFBGZXN5UGJHLzVXS2lvcmRpV2cvQUF0TWh4RUYwdzNnRm1hZTV2disyZEw0RDQrTUFJeENNcG5jS1I2UFh3RGdMQUFUVGVjUmVmRTRFZjIwYjlXdlhBMkpSdGk5UFpTWitmQWdDQjRzNWszcjZ1bytIWWJodzdEN015UlVTaDJZU3FVYU4zN0JkZDFEQVZ3QzRGUEdVb2w4NmdCd2N6YWJ2V0hKa2lYL01SMG1hbXgrODFwdm4zMzJtZERWMWZVbFp2NGFnSSthemlOR3JCdkFYNVZTMTZSU3FYNzMxcnV1ZXpXQWk0c2JhOFJXSnhLSldjV2E2NHhRb1orcmZkLy9SbjkvNERoT0RSR2RDK0FVQU9PS0cwdmtRUnVBVzhJd3ZLNmxwV1dkNlRCUkpSMkFQTkJhVnpEemNRQXVBcUJONXhGRGVwdVpid0Z3VXhBRXF3Zjd4dXJxNmtSVlZkVmlBTW5pUkJ1MVAvbStmMnd4YnVTNjdoOEFuRkNNZTQzQmMxVlZWYnF4c1hIUTZicWFtcG9kNC9INCtXRVluaW5IRjBkQ2lvaCtQbUhDaEhzYkd4c3pwc05FblhRQThxeW1wbVptUEI0L1dUNVFyT1FCdUlXSS90Znp2UGVIKzZLYW1wcVpzVmdzQmN1ZkZKbjV4Q0FJN2k3a1BSekhPWkdJYkM5SzFNM01zNE1nV0RMY0YxUlhWeWNtVHB4NEpET2ZCZUJBeUdlalRUb0IzQTNnRnQvM1BkTmhTb244a0JkSVEwUER1UFhyMXgrUiswQTV5SFNlTXJZV3dIeWwxSTJwVk9yWjBWNUVhMzBwTTErWngxeUZzSTZJYWdwVk1DZ3FoWDZZK2RJZ0NLNGE3ZXRyYTJ0M2pjVmlwelB6YVFBK2tzZG9ZbVE4QUxlazArbTdUTzEwS1hYU0FTaUN1cnE2dmNJd1BCSEE4UUJtbU01VEJqclJPN2QvTnpNL21xY1Q4NVRydWs4QTJEOFAxeXFreDN6ZlB4ajVMeGhFcnV2ZUQrQ3dQRjgzMzU2Wk1XUEdKK2ZQbjU4ZDY0VzAxaFVBRG1ibUV3QWNCV0RDbU5PSm9id0U0TjVzTnZzSDI0NjdMa1hTQVNpeTNNRXB4d000RHNESERNY3BKUnVJNlA0d0RPOGVOMjdjQTAxTlRSdnlmWU5rTWprdEhvOHZnZjBOd2ZtKzc5K1V6d3M2am5NK0VkMlF6MnNXd0h0aEdEb3RMUzB2NWZ2Q2MrZk9IZC9WMVhVNEVaMEE0RE9RODBEeTZSVUE5eExSUFo3bithYkRsQlBwQUpoRHJ1dk9ZZWFqbEZLSE1uTU41TC9IU1AwSHdQMEEva0ZFajQ5a1huKzB0TlpuTVBPdkMzMmZNY3Byd2FCY29SOFB3QmI1dUY2aE1QTVpRUkQ4cHREM1NTYVRXeXFsRGxKS0hRN2djQUJUQzMzUEVzTUFXcGo1SWFYVVh6M1BXd3g3UzF5WE5HbHdMT0U0emxRQWh4TFJvUUErRFdCcnc1RnMxTVBNaTVWU0R3TzQzL084QUFZK09Gelh2US9BTWNXKzd3amxwV0JRUTBORHZMT3o4MmtBYy9LVXExRCs3dnYra1FidVM2N3J1Z0ErQytCZzlKWVZsMk9STjdjV3dLTUFIb3JGWWcvS1FUMTJrQTZBaFJvYUd1THIxcTJiclpUYUY4QytBUFlHc0ozaFdDYjBNUE5pSW1wVVNpM283dTUrcHJXMTlUM1RvUnpIbVFSZ0tSSHRZRHJMRUs3d2ZmOTdZN21BNjdwWEFMZzhQM0VLNXExWUxEYkxoa1lsbVV4dVdWRlJzUTh6N3crZ0FlWGJJWGdMd0RNQW5tYm1wNnVycXhmblkxMkd5Qy9wQUVRRHVhNjdCelB2VFVUN0VsRTlNKzhPSUc0NldCNHhnQlZFbEFyRE1BVWdwWlJLRldOWWZ6UnFhMnVQVWtyOXhYU09JWXlwWUpEVzJtWG1mOEh5Qm95WjV3VkI4RWZUT2ZxVFRDYTNqTVZpZFVxcE9tYXVBMUFIb05wMHJqenJBYkFjUUlxWm4xWktMZlE4N3dYVG9jVFFwQU1RVVRObnpxd2NQMzc4ekd3Mk80dUk5Z0pRQTJBV2dDbUdvdzNIRzh6OEhCRXRCN0NjbVpjeWN5cHFKM281am5NYkVaMXFPc2NRVnFUVGFXZWsyNmdpVk9qbk50LzNUek1kWWlScWEydTNKcUk2SXBvRllBLzAvaHZ2aVdoc09Wd040RmtBUzNMdjI2VTlQVDNQTFZ1MnJOdDBNREZ5MGdFb01jbGtjc3ZLeXNwcFlSaE9JNkpwekx3TGdHbEV0QXN6VDBMdlZFS2hEN1I1QThEcnVWK3ZNdlByUlBRNmdKVTlQVDNMbHk1ZHVyYkE5eStLT1hQbVZQWDA5Q3dCc0l2cExFTzR5ZmY5ODBmeUF0ZDFid0p3WG9IeTVBVVJ2ZDdkM1owc2xaK251WFBuYnR2VjFiVTdFYzBnb3AyWWVVZjA3aFRhQ2NDT0tId0hvUXZBMitoOS83NEM0QlZtWGtWRXE3TFo3S3A0UEw3SzFoRTVNVHJTQVNoRHVYbks3UUJzejh5VGlLZ0t3RVJtVmdBcW1YbExBQ0NpS2lMYVdBaW5Jd3pETVBmMWRlZ3RRdE5KUkd1VlVtc3ptY3pheXNyS2R4WXZYcndXUUdqaTcyVkNLUllNY2h6bklDSjZCSFovUG14VzZLY01LSzMxdHRsc2RwdDRQTDVOR0liYk1QTzJSRFFCQURIejFnQ2dsRkxJRlNsajVpd3pkd0lBRWIwSG9KdUlRZ0FkdWZmdm13RGU2dW5wZWR1RzlUV2l1R3grZ3dzUkNZN2pYRU5FWHplZFl3akRLaGdVb1VJLzEvaStmNG5wRUVKRW1USWRRSWlvVzc5Ky9YOERhRFdkWXdoVHU3dTdoendjU0NuMVM5amYrRDlYVlZYMUhkTWhoSWc2R1FFUUlnOXFhMnRybFZLTEFGU2F6aktZd1FvR3VhNTdESUQ3aWh4cHBIcVllZThnQ0ZLbWd3Z1JkVGJQV3dvUkdlM3Q3ZTFUcDA3Tm9yZVNuTFdJNktDZGR0cnBydFdyVjNmMi9YcnVJS29IaWNqcUkyNko2TnUrNzk5ck9vY1FwVUNtQUlUSUU4L3pyZ0t3d0hTT0lXeWR5V1IrZ3crUC9oRVIzV3A3bFQ4QXoweWZQdjFxMHlHRUtCWFNBUkFpZjhKTUpuTWFnUFdtZ3d5R2lEN3R1dTY1RzMvdnV1NTVzTC9LMzN0aEdINVJUcE1USW45a0RZQVFlZWE2N3BrQWJqR2RZd2p2SzZWY1pzNHdjd3VBclV3SEdnd1JuZWw1M3EybWN3aFJTcVFESUVRQnVLNzdkL1FXaUxFV015OEdBQ0thYlRyTEVQN2grLzRScGtNSVVXcEs2U3g1SWF6QnpGK0M1UVdESXREd0E3MkZmczQwSFVLSVVpUnJBSVFvZ0NBSTNtVG1zMDNuaURwbVBzZUdLbjlDbENMWkJpaEVnYlMzdHkrZlBIbnlOQ0txTlowbG9tNExndUJLMHlHRUtGVXlBaUJFQVZWV1ZsNEE0TittYzBRTkViM2UwOVB6TmRNNWhDaGwwZ0VRb29BV0xWclVTVVJmQUNEYjE0WXZCSEJLcVZUNUU4SldNZ1VnUklHMXRiVzlPbm55NUNvaTJ0dDBsb2o0bWUvN3RtK2pGQ0x5WkFSQWlDS0lTTUVnRzBpaEh5R0tSTTRCRUtKSW9sSXd5Q0FwOUNORUVja1VnQkJGRXBXQ1FhWklvUjhoaWt1bUFJUW9vbHpCb0grYXptRWhLZlFqUkpISkZJQVFSWlpNSnFmRjQvRWxBQ2FZem1LSjk4SXdkRnBhV2w0eUhVU0ljaUlqQUVJVVdXdHI2eW9BWHplZHd4WkVkS0UwL2tJVW40d0FDR0ZJRkFvR0ZjSER2dThmQm9CTkJ4R2kzTWdJZ0JDR01QT1htSG1ONlJ3R3ZSV0x4YjRJYWZ5Rk1FSTZBRUlZVXU0Rmc0am9YQ24wSTRRNXNnMVFDSVBLdUdEUWJiN3YvOWgwQ0NIS21Zd0FDR0ZZdVJVTWtrSS9RdGhCT2dCQ0dGWm1CWU9rMEk4UWxwQXBBQ0VzME5iVzl1clVxVk1uQXBock9rc2hNZk8xVXVoSENEdklDSUFRbHVqbzZMZ013RkxUT1Fyb3VYSGp4a21oSHlFc0lSMEFJU3l4WXNXS2RCaUdwd0RvTnAybEFIcVkrZFNtcHFZTnBvTUlJWHJKRklBUUZpblZna0ZTNkVjSSs4Z0lnQkNXS2NHQ1FWTG9Sd2dMeVZIQVFsaW9oQW9HU2FFZklTd2xVd0JDV0dqTm1qWHJwa3laOGphQUkweG5HYU92QkVId3FPa1FRb2pOeVFpQUVCYUxlTUVnS2ZRamhNVmtEWUFRRm90d3dTQXA5Q09FNWFRRElJVEZvbG93U0FyOUNHRS9XUU1naE9YYTI5dVhUNTA2ZFRxQUd0Tlpob09aYjVkQ1AwTFlUMFlBaElpR1NCUU1JcUxYTTVuTVJhWnpDQ0dHSmgwQUlTTEE4N3dPQUNmRDdvSkJVdWhIaUFpUktRQWhJc0wyZ2tGUzZFZUlhSkVSQUNFaXhPS0NRVkxvUjRpSWtRNkFFQkZpYWNFZ0tmUWpSQVRKRklBUUVkUGUzdDQrWmNxVUVKWVVEQ0tpNzBpaEh5R2lSMFlBaElnZzMvZC9BanNLQmowemZmcjBuNW9PSVlRWU9Ua0tXSWlJc3FCZ2tCVDZFU0xDWkFwQWlJaXlvR0NRRlBvUklzSmtCRUNJaUROVU1FZ0svUWdSY2JJR1FJaUl5MlF5cHdONG80aTNsRUkvUXBRQTZRQUlFWEd0cmExdkVGSFJDZ1pKb1I4aFNvT3NBUkNpQkxTMXRiMVFqSUpCVXVoSGlOSWhJd0JDbEk2Q0ZneVNRajlDbEJicEFBaFJJdm9VREFvTGNIa3A5Q05FaVpFcEFDRktTRnRiMjZ0VHBrelpHbmt1R0VSRVAvYzg3K1o4WGxNSVlaYU1BQWhSWWpvN083K0YvQllNZXE2eXN2TGJlYnllRU1JQzBnRVFvc1RrdVdDUUZQb1Jva1RKRklBUUpTaGZCWU9rMEk4UXBVdEdBSVFvVVhrb0dOUWtoWDZFS0YzU0FSQ2lkSVd4V093MEFPdEg4ZHIzd2pBOGRmNzgrZGw4aHhKQzJFR21BSVFvWWF0WHIxNDdaY3FVZHpEeVdnSG5TNkVmSVVxYkZBTVNvZ3lNc0dDUUZQb1JvZ3pJRklBUVpXQUVCWU9rMEk4UVpVSTZBRUtVZ2VFV0RKSkNQMEtVRDFrRElFU1phR3RyZTJIS2xDa3pNRURCSUNLNncvTzhIeFU1bGhEQ0VCa0JFS0tNRU5INTZLZGdFQkc5M3QzZGZhR0JTRUlJUTZRRElFUVpHYUJna0JUNkVhSU15UlNBRUdWbTA0SkJVdWhIaVBJa0l3QkNsS0UrQllPZWwwSS9RZ2doUkJuUldydGFhOWQwRGlHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NDR0VFRUlJSVlRUVFnZ2hoQkJDQ0NHRUVFSUlJWVFRUWdnaGhCQkNDQ0dFRUVJSUlZUVFRZ2doaEJCQ0NNUCtEeWNlSG03cm96UGtBQUFBQUVsRlRrU3VRbUNDIiB3aWR0aD0iNTEyIiBoZWlnaHQ9IjUxMiIgLz48L3N2Zz4="},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"7QsIM":[function(e,l,a){var t=e("@parcel/transformer-js/src/esmodule-helpers.js");t.defineInteropFlag(a),t.export(a,"logger",()=>N);let d="\uD83D\uDE80 [Vesti]",V="color: #00d2ff; font-weight: 700;",U="color: #8a8a8a; font-weight: 600;",n="color: #222;",c="color: #1f9d55; font-weight: 700;",s="color: #b7791f; font-weight: 700;";function R(e,l){return`%c${d} %c[${e}] %c${l}`}let N={info(e,l,a){void 0!==a?console.log(R(e,l),V,U,n,a):console.log(R(e,l),V,U,n)},success(e,l,a){void 0!==a?console.log(R(e,l),V,U,c,a):console.log(R(e,l),V,U,c)},warn(e,l,a){void 0!==a?console.warn(R(e,l),V,U,s,a):console.warn(R(e,l),V,U,s)},error(e,l,a){console.error(R(e,l),V,U,"color: #c53030; font-weight: 700;",a)},group(e,l){console.groupCollapsed(`%c${d} %c${e}`,V,U);try{l()}finally{console.groupEnd()}}}},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"9T4FN":[function(e,l,a){l.exports=e("1ba3768e73e8e7c3").getBundleURL("b89Na")+e("dcb436b9d8878fdd").resolve("USxDI")},{"1ba3768e73e8e7c3":"6haDs",dcb436b9d8878fdd:"amLA4"}],"6haDs":[function(e,l,a){var t={};function d(e){return(""+e).replace(/^((?:https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/.+)\/[^/]+$/,"$1")+"/"}a.getBundleURL=function(e){var l=t[e];return l||(l=function(){try{throw Error()}catch(l){var e=(""+l.stack).match(/(https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/[^)\n]+/g);if(e)return d(e[2])}return"/"}(),t[e]=l),l},a.getBaseURL=d,a.getOrigin=function(e){var l=(""+e).match(/(https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/[^/]+/);if(!l)throw Error("Origin not found");return l[0]}},{}],cljvb:[function(e,l,a){l.exports=e("f917983c9a016a3b").getBundleURL("b89Na")+e("6f16b3722b51f894").resolve("i1CcF")},{f917983c9a016a3b:"6haDs","6f16b3722b51f894":"amLA4"}],"9NolI":[function(e,l,a){l.exports=e("46e89db8dae4f7f5").getBundleURL("b89Na")+e("dadc585d55f6fb2c").resolve("h4erl")},{"46e89db8dae4f7f5":"6haDs",dadc585d55f6fb2c:"amLA4"}],f9lbz:[function(e,l,a){l.exports=e("9e1064190898a15f").getBundleURL("b89Na")+e("784130f81a27d2fe").resolve("lIcJ6")},{"9e1064190898a15f":"6haDs","784130f81a27d2fe":"amLA4"}],kLs50:[function(e,l,a){l.exports=e("6dfe8c12db683de4").getBundleURL("b89Na")+e("7a6ee66a855fad0a").resolve("2j86x")},{"6dfe8c12db683de4":"6haDs","7a6ee66a855fad0a":"amLA4"}],"6mRIM":[function(e,l,a){l.exports=e("e83f3b7411eca194").getBundleURL("b89Na")+e("6a1ac9cd3f37bda5").resolve("a9nVW")},{e83f3b7411eca194:"6haDs","6a1ac9cd3f37bda5":"amLA4"}]},["9lnB4","e7XAi"],"e7XAi","parcelRequireb92d"),globalThis.define=l;